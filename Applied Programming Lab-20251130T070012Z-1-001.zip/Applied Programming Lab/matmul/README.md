The code attached herewith shows how matrix multiplication is implemented.

# Principle-

    * The algorithm implements matrix multiplication. a matrix of the order M * K wherein the first matrix is of the order M * N and the second is of N * K. 
    * The results of the multiplication is obtained by multiplying the rows of the first column and the columns of the second.

# Algorithm-
    
First, it verifies that both m1 and m2 are lists of lists, indicating they are matrices. If either of them is not a list of lists, a TypeError is raised. Next, it checks if m1 and m2 are non-empty matrices by ensuring that both matrices have at least one row and one column. If either of them is empty, an IndexError is raised. Then, the code checks if the dimensions of the input matrices are compatible for matrix multiplication. For matrix multiplication to be valid, the number of columns in m1 must be equal to the number of rows in m2. If the dimensions are incompatible, a ValueError is raised.

Assuming all the checks pass, the code initializes an empty result matrix with dimensions MxK, where M is the number of rows in m1, and K is the number of columns in m2. It then proceeds to perform matrix multiplication using nested loops. For each element in the result matrix, it calculates the dot product of corresponding elements from m1 and m2 and accumulates the sum in the appropriate position of the result matrix.

Finally, the function returns the resulting matrix, which is the product of the input matrices m1 and m2. If any non-numeric elements are found in the input matrices during the multiplication process, a TypeError is raised. Otherwise, the result matrix is returned.
    
        
# Exception-

The exception cases are the cases which need to be tested for and the code needs to show an error in case of these cases. The following are some of the test cases and exceptions that need to be kept in mind:

    # Things to be tested
    # - test cases with valid matrices - last
    # - Non-numeric input should result in TypeError
    # - Mismatched axes should result in ValueError - matrices but wrong kind
    # - Non-matrices - IndexError or TypeError? - catch and change Error 
    # Note: we cannot test Type == List since any iterable type should be OK.
    # Also, checking all the sublists to see size is probably a waste in general.
    # Instead we can rely on the IndexError if we go out of bounds.


# Result-

The code outputs a matrix of the order M * K wherein the first matrix is of the order M * N and the second is of N * K. The products of the the matrices are stored in 
     
        
