def matmul(m1, m2):
    
    # Checking if m1 and m2 are not list or tuple
    if not isinstance(m1, (tuple, list)):
        raise TypeError("m1 must be a list or tuple")
    
    if not isinstance(m2, (tuple, list)):
        raise TypeError("m2 must be a list or tuple")

    # Checking if m1[0] and m2[0] are not list or tuple
    if not isinstance(m1[0], (tuple, list)):
        raise TypeError("Elements of m1 must be a list or tuple")

    if not isinstance(m2[0], (tuple, list)):
        raise TypeError("Elements of m2 must be a list or tuple")

    # Checking if m1 and m2 are matrices (lists of lists)
    if not isinstance(m1, list) or not isinstance(m2, list):
        raise TypeError("Both input matrices must be lists of lists")
        
    # Checking if m1 is a non-empty matrix
    if not m1 or not m1[0]:
        raise IndexError("Input matrices must be non-empty")

    # Checking if m2 is a non-empty matrix
    if not m2 or not m2[0]:
        raise IndexError("Input matrices must be non-empty")

    # Checking if m1 and m2 have compatible dimensions for matrix multiplication
    M = len(m1)
    N = len(m1[0])
    K = len(m2[0])

    if N != len(m2):
        raise ValueError("Mismatched dimensions for matrix multiplication")
        
    # Initializing the result matrix
    result = [[0 for _ in range(K)] for _ in range(M)]

    for i in range(M):
        for j in range(K):
            dot_product = 0
            for k in range(N):
                elem1 = m1[i][k]
                elem2 = m2[k][j]
                #Checking if the elements of m1 and m2 are numeric:
                if not isinstance(elem1, (int, float, complex)) or not isinstance(elem2, (int, float, complex)):
                    raise TypeError("Non-numeric input found in the matrices")
                dot_product += elem1 * elem2
            result[i][j] = dot_product
            
    return result
