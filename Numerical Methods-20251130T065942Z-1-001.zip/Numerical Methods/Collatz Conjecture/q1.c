#include<stdio.h>

//Variable Declarations

//The initial Number
int input;

//First Stopping Time, Step and Orbit Peak

/*
For the firststop Array:
0th Element: Checks if first stopping time has been attained
1st Element: The first stopping time
*/
int firststop[2]={0,0};

//step and peak
int step=0,peak=0;

int collatz(int num)
{
    step++;

    // n/2 if n is even, (3n+1)/2 if n is odd
    if ((num%2)==0)
    {
        num=num/2;
    }
    
    else
    {
        num=(num*3)+1;
    }
    
    //store the first stopping time when it has been obtained
    if (firststop[0]==0 && num<input)
    {
        firststop[1]=step;
        firststop[0]=1;
    }

    //storing the max value of peak (the classic method)
    if (num>peak)
    {
        peak=num;
    }
    
    return num;
}

int main() {

    //Taking Input
    int editednum=0;
    printf("Enter a positive number:");
    scanf("%d",&input);
    editednum=input;
    
    //Finding the peak and first stopping time using while loop
    while(editednum!=1)
    {
        editednum=collatz(editednum);
    }
    
   printf("\nThe First Stopping Time is: %d\n",firststop[1]);
   printf("The Orbit Peak is: %d",peak);
}