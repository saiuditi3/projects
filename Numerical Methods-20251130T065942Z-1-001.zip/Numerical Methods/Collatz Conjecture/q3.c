#include<stdio.h>

//Variable Declarations

//The number that is being checked:
int initialint=0;

int step=0;

/*
The First Stopping Time, Total Stopping Time and Orbit Peak 
These will be reused for each number in the for Loop
*/
int firststop[2]={0,0},totalstop=0,peak=0;


/*
These are the Arrays storing the largest First Stopping Time, Total Stopping Time and Orbit Peak
The Element at Index 0 is the value of these respectively and the rest are the numbers for which these are attained
*/
int LargestFirstStop[5]={0,0,0,0,0};int LargestTotStop[5]={0,0,0,0,0};int LargestPeak[5]={0,0,0,0,0};


//Function to Reset the above arrays:
int cleararr(int arr[5])
{
    for(int i=0;i<5;i++)
    {
        arr[i]=0;
    }
}


//The Recursive Function
unsigned int collatz(unsigned int n)
{
    //Recursion Termination Condition(Terminates when the number becomes 1):
    if (n==1)
    {
        totalstop=step;
        return 0;
    }

    //To check if First Stopping Time has been stored, and store it if necessary:
    if (firststop[0]==0 && n<initialint)
    {
        firststop[1]=step;
        firststop[0]=1;
    }

    //To check and assign the orbit peak:
    if (n>peak)
    {
        peak=n;
    }

    //The Collatz Conjecture Part of Taking 3n+1 if n is odd and n/2 if n is even:
    if (n%2==0)
    {
        n=n/2;
    }

    else
    {
        n=n*3+1;
    }

    //Incrementing step,i.e, counting the number of steps:
    step++;

    //Calling the same function(Recursion):
    collatz(n);
}

int main()
{
    for(int i=1;i<1000;i++)
    {
        //Resetting the variables:
        initialint=i;
        firststop[0]=firststop[1]=0;
        totalstop=0; peak=0; step=0;
        
        //Running the Recursive Function:
        collatz(i);
        
        /*
        To check if the Parameters obtained for a number are the largest
        The else condition is to ensure that elements are added to the array
        */

        //To compare and assign the largest orbit peak to the corresponding Array:
        if (peak>LargestPeak[0])
        {
            cleararr(LargestPeak);
            LargestPeak[0]=peak;
            LargestPeak[1]=initialint;
        }

        else if (peak==LargestPeak[0])
        {
            for(int j=1;j<5;j++)
            {
             if(LargestPeak[j]==0)
                {
                 LargestPeak[j]=initialint;
                 break;
                }
            }
        }


        //To compare and assign the largest Total Stopping Time to the corresponding Array
        if (totalstop>LargestTotStop[0])
        {
            cleararr(LargestTotStop); 
            LargestTotStop[0]=totalstop;
            LargestTotStop[1]=initialint;
        }
        
        else if (totalstop==LargestTotStop[0])
        {
            for(int j=1;j<5;j++)
            {
             if(LargestTotStop[j]==0)
                {
                 LargestTotStop[j]=initialint;
                 break;
                }
            }
        }



        //To compare and assign the largest First Stopping Time to the corresponding Array
        if (firststop[1]>LargestFirstStop[0])
        {
            cleararr(LargestFirstStop); 
            LargestFirstStop[0]=firststop[1];
            LargestFirstStop[1]=initialint;
           
        }
        else if (firststop[1]==LargestFirstStop[0])
        {
            for(int j=1;j<5;j++)
            {
                
             if(LargestFirstStop[j]==0)
                {
                    LargestFirstStop[j]=initialint;
                    break;
                }
            }
        }

    }
    
    //Printing the Final Outputs

    //First Stopping Time Data:
    printf("\n\nFirst Stopping Time\n");
    printf("Largest First Stopping Time: %d\n",LargestFirstStop[0]);
    printf("Numbers: ");

    for(int i=1;i<5;i++)
    {
        if (LargestFirstStop[i]==0)
        {
            break;
        }
        printf("%d   ",LargestFirstStop[i]);
    }
    
    

    //Total Stopping Time Data:
    printf("\n\nTotal Stopping Time\n");
    printf("Largest Total Stopping Time: %d\n",LargestTotStop[0]);
    printf("Numbers: ");
    for(int i=1;i<5;i++)
    {
        if (LargestTotStop[i]==0)
        {
            break;
        }
        printf("%d   ",LargestTotStop[i]);
    }

    
    
    //Orbit Peak Data:
    printf("\n\nOrbit Peak\n");
    printf("Largest Orbit Peak: %d\n",LargestPeak[0]);
    printf("Numbers: ");
    for(int i=1;i<5;i++)
    {
        if (LargestPeak[i]==0)
        {
            break;
        }
        printf("%d   ",LargestPeak[i]);
    }

}