#include<stdio.h>

//Note:The highest total stopping time is 261

//Variable to count step
int step=0;

//Recursive Collatz Function
unsigned int collatz(unsigned int n)
{
    //Recursion Termination Condition
    if (n==1)
    {
        return step;
    }

    step++;

    // n/2 if n is even, (3n+1)/2 if n is odd
    if (n%2==0)
    {
        n=n/2;
    }

    else
    {
        n=n*3+1;
    }


    //Recursion- Calling the Collatz Function
    collatz(n);
}

int main() {

    //Opening the file to write data to
    FILE *fp = NULL;
    fp = fopen("q4.txt","w");

    //Loop to add the integer as well as its total stopping time into the file
    int i=1;
    while(i<=9999)
    {
        step=0;
        printf("%d\n",i);
        int printstep=collatz(i);
        fprintf(fp,"%d\t %d\n",i, printstep);
        i+=2;
    }

    return 0;

   
}