#include<Stdio.h>
#include<math.h>

int step=0;

double OldIntegral=0,NewIntegral=0;

FILE *midpfilerel=NULL;
FILE *simpsonfilerel=NULL;
FILE *trapezfilerel=NULL;

FILE *midpfileabs=NULL;
FILE *simpsonfileabs=NULL;
FILE *trapezfileabs=NULL;

//Function to calculate the error
double Errorcalc(double oldintegral, double newintegral)
{
    return fabs((newintegral-oldintegral)/newintegral)*100;
}

//Returns the value of the function
double f(double x)
{
    return 2*sin(x/2);
}

double midpoint(double lower, double upper, float n)
{
    double integral=0.0;

    //Find dx from number of divisions(n)
    double dx=(upper-lower)/n;

    
    while(lower<upper)
    {
        integral+= f(lower+dx/2)*dx;
        lower+=dx;
    }
    
    OldIntegral=NewIntegral;
    NewIntegral=integral;

    //Writing error to file
    fprintf(midpfilerel,"%d\t%lf\n",step+1,Errorcalc(OldIntegral,NewIntegral));
    fprintf(midpfileabs,"%d\t%lf\n",step+1,Errorcalc(8,NewIntegral));

    step+=1;

    return integral;
}

//Calculates the Integral by trapezoidal method
double trapezoidal(double lower, double upper, float n)
{
    double integral=0.0;
    double dx=(upper-lower)/n;
    
    integral+=f(lower);
    lower+=dx;

    while(lower<upper)
    {
        integral+= 2*f(lower);
        lower+=dx;
    }
    integral+=f(lower);

    integral=(dx/2)*integral;

    OldIntegral=NewIntegral;
    NewIntegral=integral;

    //Writing error to file
    fprintf(trapezfilerel,"%d\t%lf\n",step+1,Errorcalc(OldIntegral,NewIntegral));
    fprintf(trapezfileabs,"%d\t%lf\n",step+1,Errorcalc(8,NewIntegral));

    step+=1;

    return integral;
}

//Calculates the Integral by simpson's method
double simpsons(double lower, double upper, float n)
{   
    int count=0;
    double integral=0.0;
    double dx=(upper-lower)/n;
    
    integral+=f(lower);
    lower+=dx;
    count+=1;

    while(lower<upper)
    {
        if(count%2==1)
        {
            integral+= 4*f(lower);
        }

        else
        {
            integral+=2*f(lower);
        }

        lower+=dx;
        count++;
    }

    integral+=f(lower);

    integral=(dx/3)*integral;

    OldIntegral=NewIntegral;
    NewIntegral=integral;

    //Writing error to file
    fprintf(simpsonfilerel,"%d\t%lf\n",step+1,Errorcalc(OldIntegral,NewIntegral));
    fprintf(simpsonfileabs,"%d\t%lf\n",step+1,Errorcalc(8,NewIntegral));
    
    step+=1;
    return integral;
}

int main()
{    
    //File to store relative errors
    midpfilerel=fopen("q1amidp_Rel.txt","w");
    trapezfilerel=fopen("q1atrapez_Rel.txt","w");
    simpsonfilerel=fopen("q1asimpson_Rel.txt","w");
    
    //File to store absolute errors
    midpfileabs=fopen("q1amidp_Abs.txt","w");
    trapezfileabs=fopen("q1atrapez_Abs.txt","w");
    simpsonfileabs=fopen("q1asimpson_Abs.txt","w");
    
    //Calculate the integral by Midpoint method and print it:
    printf("\nMidpoint Method:\n\n");
    printf("n\tValue of Integral\n");
    int i=2;step=0;
    while(i<=1024)
    {
        printf("%d\t%0.8lf\n",i,midpoint(0,2*M_PI,i));
        i*=2;
    }

    //Calculate the integral by Trapezoidal method and print it:
    printf("\nTrapezoidal Method:\n\n");
    printf("n\tValue of Integral\n");
    
    i=2;step=0;
    while(i<=1024)
    {
        printf("%d\t%0.8lf\n",i,trapezoidal(0,2*M_PI,i));
        i*=2;
    }

    //Calculate the integral by Simpson's method and print it:
    printf("\nSimpson's 1/3rd Method:\n\n");
    printf("n\tValue of Integral\n");
    
    i=2;step=0;
    while(i<=1024)
    {
        printf("%d\t%0.8lf\n",i,simpsons(0,2*M_PI,i));
        i*=2;
    }

}