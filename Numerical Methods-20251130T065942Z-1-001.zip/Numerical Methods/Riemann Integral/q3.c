#include<Stdio.h>
#include<math.h>

int step=0;

double OldIntegral=0,NewIntegral=0;

//Function to Calculate Errors
double Errorcalc(double oldval, double newval)
{
    return fabs((newval-oldval)/newval)*100;
}

//Returns the Value of the Function
double f(double x)
{
    return pow(x,-x);
}

//Calculate the error by Midpoint Method
double midpoint(double lower, double upper, float n)
{
    double integral=0.0;

    //Find dx from n
    double dx=(upper-lower)/n;
    
    while(lower<upper)
    {
        integral+= f(lower+dx/2)*dx;
        lower+=dx;
    }

    step+=1;

    return integral;
}

//Find the integral using Trapezoidal Method
double trapezoidal(double lower, double upper, float n)
{
    double integral=0.0;
    double dx=(upper-lower)/n;
    
    integral+=f(lower);
    lower+=dx;

    while(lower<upper)
    {
        integral+= 2*f(lower);
        lower+=dx;
    }
    integral+=f(lower);

    integral=(dx/2)*integral;

    step+=1;

    return integral;
}

//Find the integral by Simpson's Method
double simpsons(double lower, double upper, float n)
{   
    int count=0;
    double integral=0.0;
    double dx=(upper-lower)/n;
    
    integral+=f(lower);
    lower+=dx;
    count+=1;

    while(lower<upper)
    {
        if(count%2==1)
        {
            integral+= 4*f(lower);
        }

        else
        {
            integral+=2*f(lower);
        }

        lower+=dx;
        count++;
    }

    integral+=f(lower);

    integral=(dx/3)*integral;
    
    step+=1;
    return integral;
}

int main()
{
    //Integral by using Midpoint Method
    printf("\nMidpoint Method:\n");
    printf("%0.15lf\n",midpoint(0,1,1024));

    //Midpoint using Trapezoidal Method
    printf("\nTrapezoidal Method:\n");
    printf("%0.15lf\n",trapezoidal(0,1,1024));

    //Integral using Simpson's Method
    printf("\nSimpson's 1/3rd Method:\n"); 
    printf("%0.15lf\n",simpsons(0,1,1024));

    //Finding the RHS by summation
    double sum=0.0;
    float x=1;
    while(pow(x,-x)>pow(10,-17))
    {
        sum+=pow(x,-x);
        x++;
    }

    printf("\nBy summation the answer is:\n%0.15lf\n\n",sum);

    //Print the Percent relative errors wrt the answer obtained by summation
    printf("The percent relative errors wrt the answer obtained by summation is:\n\n");
    printf("Midpoint Method: %0.15lf%%\nTrapezoidal Method: %0.15lf%%\nSimpson's 1/3rd Method: %0.15lf%%",Errorcalc(midpoint(0,1,1024),sum),Errorcalc(trapezoidal(0,1,1024),sum),Errorcalc(simpsons(0,1,1024),sum));
}