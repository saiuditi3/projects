#include<Stdio.h>
#include<math.h>

int step=0;
double OldIntegral=0,NewIntegral=0;

//File to store Errors for Erp1
FILE *midpfile_Erp1=NULL;
FILE *simpsonfile_Erp1=NULL;
FILE *trapezfile_Erp1=NULL;

//File to store Errors for Erp2
FILE *midpfile_Erp2=NULL;
FILE *simpsonfile_Erp2=NULL;
FILE *trapezfile_Erp2=NULL;

//Function to Calculate Errors
double Errorcalc(double oldintegral,double newintegral)
{
    return fabs((newintegral-oldintegral)/newintegral)*100;
}

//Returns the Value of the Function
double f(double x)
{
    return (1/sqrt(2*M_PI))*exp(-(x*x)/2);
}

//Calculates the Integral by midpoint method
double midpoint(double lower, double upper, float n, FILE *file)
{
    double integral=0.0;

    //Find dx from number of divisions(n)
    double dx=(upper-lower)/n;
    
    while(lower<upper)
    {
        integral+= f(lower+dx/2)*dx;
        lower+=dx;
    }
    
    OldIntegral=NewIntegral;
    NewIntegral=integral;

    //Writing error to file
    fprintf(file,"%d\t%lf\n",step+1,Errorcalc(OldIntegral,NewIntegral));

    step++;
    return integral;
}

//Calculates the Integral by trapezoidal method
double trapezoidal(double lower, double upper, float n,FILE *file)
{
    double integral=0.0;
    double dx=(upper-lower)/n;
    
    integral+=f(lower);
    lower+=dx;

    while(lower<upper)
    {
        integral+= 2*f(lower);
        lower+=dx;
    }
    integral+=f(lower);

    integral=(dx/2)*integral;

    OldIntegral=NewIntegral;
    NewIntegral=integral;

    //Writing error to file
    fprintf(file,"%d\t%lf\n",step+1,Errorcalc(OldIntegral,NewIntegral));

    step++;
    return integral;
}

//Calculates the Integral by simpson's method
double simpsons(double lower, double upper, float n,FILE *file)
{   
    int count=0;
    double integral=0.0;
    double dx=(upper-lower)/n;
    
    integral+=f(lower);
    lower+=dx;
    count+=1;

    while(lower<upper)
    {
        if(count%2==1)
        {
            integral+= 4*f(lower);
        }

        else
        {
            integral+=2*f(lower);
        }

        lower+=dx;
        count++;
    }

    integral+=f(lower);

    integral=(dx/3)*integral;

    OldIntegral=NewIntegral;
    NewIntegral=integral;

    //Writing error to file
    fprintf(file,"%d\t%lf\n",step+1,Errorcalc(OldIntegral,NewIntegral));
    step++;
    return integral;
}

int main()
{
    //File to store Errors for Erp(1)
    midpfile_Erp1=fopen("q2midp_1.txt","w");
    trapezfile_Erp1=fopen("q2trapez_1.txt","w");
    simpsonfile_Erp1=fopen("q2simpson_1.txt","w");

    //Files to store errors for Erp(2)
    midpfile_Erp2=fopen("q2midp_2.txt","w");
    trapezfile_Erp2=fopen("q2trapez_2.txt","w");
    simpsonfile_Erp2=fopen("q2simpson_2.txt","w");
    
    printf("\nErf(1):\n");
    printf("Midpoint Method:\n\n");
    printf("n\tValue of Integral\n");
    
    //Calculate the integral by Midpoint method and print it:
    printf("Midpoint Method:\n\n");
    printf("n\tValue of Integral\n");
    int i=2;step=0;
    while(i<=1024)
    {
        printf("%d\t%0.8lf\n",i,midpoint(-4,1,i,midpfile_Erp1));
        i*=2;
    }

    //Calculate the integral by Trapezoidal method and print it:
    printf("\nTrapezoidal Method:\n\n");
    printf("n\tValue of Integral\n");
    
    i=2;step=0;OldIntegral=NewIntegral=0;
    while(i<=1024)
    {
        printf("%d\t%0.8lf\n",i,trapezoidal(-4,1,i,trapezfile_Erp1));
        i*=2;
    }

    //Calculate the integral by Simpson's method and print it:
    printf("\nSimpson's 1/3rd Method:\n\n");
    printf("n\tValue of Integral\n");
    
    i=2;step=0;OldIntegral=NewIntegral=0;
    while(i<=1024)
    {
        printf("%d\t%0.8lf\n",i,simpsons(-4,1,i,simpsonfile_Erp1));
        i*=2;
    }


    //Calculate the Integral for Erf(2)
    printf("\nErf(2):\n");

    //Calculate the integral by Trapezoidal method and print it:
    printf("Midpoint Method:\n\n");
    printf("n\tValue of Integral\n");
    
    i=2;step=0;OldIntegral=NewIntegral=0;
    while(i<=1024)
    {
        printf("%d\t%0.8lf\n",i,midpoint(-4,2,i,midpfile_Erp2));
        i*=2;
    }

    //Calculate the integral by Trapezoidal method and print it:
    printf("\nTrapezoidal Method:\n\n");
    printf("n\tValue of Integral\n");
    
    i=2;step=0;OldIntegral=NewIntegral=0;
    while(i<=1024)
    {
        printf("%d\t%0.8lf\n",i,trapezoidal(-4,2,i,trapezfile_Erp2));
        i*=2;
    }

    //Calculate the integral by Simpson's method and print it:
    printf("\nSimpson's 1/3rd Method:\n\n");
    printf("n\tValue of Integral\n");
    
    i=2;step=0;OldIntegral=NewIntegral=0;
    while(i<=1024)
    {
        printf("%d\t%0.8lf\n",i,simpsons(-4,2,i,simpsonfile_Erp2));
        i*=2;
    }
}