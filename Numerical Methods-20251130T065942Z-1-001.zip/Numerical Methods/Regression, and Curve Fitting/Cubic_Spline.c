#include <stdio.h>
#include <math.h>
#include<stdlib.h>

int n;//Number of points=n+1
void Spline(int n,double x[n],double y[n]);//Function to find the cubic splines
void Gauss(int n, double A[n][n], double B[n], double X[n]) ;//Function for Gaussian Elimination


int main()
{    
    printf("Enter the value of n:");
    scanf("%d",&n);
    double x[n+1],y[n+1];//xi and yi
    
    //Taking input
    for(int i=0;i<n+1;i++)
    {
        printf("Enter x%d:",i);
        scanf("%lf",&x[i]);
        printf("Enter y%d:",i);
        scanf("%lf",&y[i]);
    }

    n=4*n;
    Spline(n,x,y);
}


//Function to do Gauss Elimination to solve for AX=B
void Gauss(int n, double A[n][n], double B[n], double X[n]) 
{
    //Iterate through each row
    for (int i = 0; i < n; i++)
    {
        // Find pivot element
        int pivot = i;
        for (int j = i + 1; j < n; j++) 
        {
            if (fabs(A[j][i]) > fabs(A[pivot][i])) 
            {
                pivot = j;
            }
        }
        
        //Swap the rows
        for (int j = 0; j < n; j++)
        {
            double temp = A[i][j];
            A[i][j] = A[pivot][j];
            A[pivot][j] = temp;
        }
        double temp = B[i];
        B[i] = B[pivot];
        B[pivot] = temp;

        //Do Gauss Elimination
        for (int j = i + 1; j < n; j++) 
        {
            double factor = A[j][i] / A[i][i];
            for (int k = i + 1; k < n; k++) 
            {
                A[j][k] -= factor * A[i][k];
            }
            B[j] -= factor * B[i];
        }
    }
  
    //Back Substitution to find X
    for (int i = n - 1; i >= 0; i--) 
    {
        double sum = 0.0;
        for (int j = i + 1; j < n; j++) 
        {
            sum += A[i][j] * X[j];
        }
        X[i] = (B[i] - sum) / A[i][i];
    }
}


void Spline(int n,double x[n],double y[n])
{
    int i=0,j=0,k,//Iteration Variables
    power;//Used as power of x in loops
    double coeff[n][n],rhs[n],result[n];//A,B and X for AX=B

    //Setting all elements of matrix to 0 =>Works
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            coeff[i][j]=0;
        }
    }
    n=n/4;

    //Function Values of Adjacent Polynomials must be equal
    for(i=1;i<n;i++)                                                             
    {
        power=3;
        for(j=0;j<4;j++)
        {
            coeff[2*(i-1)][4*(i-1)+j]=pow(x[i],power);
            coeff[2*(i-1)+1][4*i+j]=pow(x[i],power);
            power--;
        }       

        rhs[2*(i-1)]=y[i];
        rhs[2*(i-1)+1]=y[i];    
    }

    //Function Values at Endpoints(0th and last functions)
    power=3;
    for(j=0;j<4;j++)
    {
        coeff[2*(i-1)][j]=pow(x[0],power);
        rhs[2*(i-1)]=y[0];
        //Works

        coeff[2*(i-1)+1][4*(n-1)+j]=pow(x[n],power);
        rhs[2*(i-1)+1]=y[n];
        power--;
    }

    i=2*i;
    k=0;
    
    //Matching the 1st derivatives at knots
    for(j=1;j<n;j++,i++,k++)
    {
        coeff[i][4*k]=3*pow(x[j],2);
        coeff[i][4*k+1]=2*x[j];
        coeff[i][4*k+2]=1;
        
        coeff[i][4*k+4]=-3*pow(x[j],2);
        coeff[i][4*k+5]=-2*x[j];
        coeff[i][4*k+6]=-1; 
    }

    //Matching the 2nd derivatives at knots
    for(j=1;j<n;j++,i++,k++)
    {
        coeff[i][4*k]=6*x[j];
        coeff[i][4*k+1]=2;
        
        coeff[i][4*k+4]=-6*x[j];
        coeff[i][4*k+5]=-2; 
    }
    
    //2nd Derivatives at the endpoints to 0
    //First Equation
    coeff[4*n-2][0]=6*x[0];
    coeff[4*n-2][1]=2;

    //Last Equation
    coeff[4*n-1][4*n-4]=6*x[n];
    coeff[4*n-1][4*n-3]=2;

    //Display the matrices obtained
    for(i=0;i<4*n;i++)
    {
        for(j=0;j<4*n;j++)
        {
            printf("%lf\t",coeff[i][j]);
        }
        printf("%lf\n",rhs[i]);
        //printf("\n");
    }

    n=4*n;

    //Gaussian Elimination to find the coefficients
    Gauss(n,coeff,rhs,result);

    //Display the function to be plotted in desmos
    for(i=0;i<n/4;i++)
    {
        printf("{%lf<x<%lf:%lfx^3+%lfx^2+%lfx+%lf}\n",x[i],x[i+1],result[4*i],result[4*i+1],result[4*i+2],result[4*i+3]);
    }
    
}