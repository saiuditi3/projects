#include <stdio.h>
#include <math.h>
#include<stdlib.h>

int n;//Number of points=n+1
void Spline(int n,double x[n],double y[n]);//Function to find the quadratic splines
void Gauss(int n, double A[n][n], double B[n], double X[n]) ;//Function for Gaussian Elimination

int main()
{    
    printf("Enter the value of n:");
    scanf("%d",&n);
    double x[n+1],y[n+1];//xi and yi
    
    //Taking xi and yi
    for(int i=0;i<n+1;i++)
    {
        printf("Enter x%d:",i);
        scanf("%lf",&x[i]);
        printf("Enter y%d:",i);
        scanf("%lf",&y[i]);
    }

    n=3*n;
    Spline(n,x,y);
}


//Function to do Gauss Elimination to solve for AX=B
void Gauss(int n, double A[n][n], double B[n], double X[n]) 
{
    //Iterate through each row
    for (int i = 0; i < n; i++)
    {
        // Find pivot element
        int pivot = i;
        for (int j = i + 1; j < n; j++) 
        {
            if (fabs(A[j][i]) > fabs(A[pivot][i])) 
            {
                pivot = j;
            }
        }
        
        //Swap the rows
        for (int j = 0; j < n; j++)
        {
            double temp = A[i][j];
            A[i][j] = A[pivot][j];
            A[pivot][j] = temp;
        }
        double temp = B[i];
        B[i] = B[pivot];
        B[pivot] = temp;

        //Do Gauss Elimination
        for (int j = i + 1; j < n; j++) 
        {
            double factor = A[j][i] / A[i][i];
            for (int k = i + 1; k < n; k++) 
            {
                A[j][k] -= factor * A[i][k];
            }
            B[j] -= factor * B[i];
        }
    }
  
    //Back Substitution to find X
    for (int i = n - 1; i >= 0; i--) 
    {
        double sum = 0.0;
        for (int j = i + 1; j < n; j++) 
        {
            sum += A[i][j] * X[j];
        }
        X[i] = (B[i] - sum) / A[i][i];
    }
}

//Function to find the quadratic Splines
void Spline(int n,double x[n],double y[n])
{
    int i=0,j=0,k,//Iteration Variables
    power;//Used as power of x in loops
    double coeff[n][n],rhs[n],result[n];//A,B and X for AX=B

    //Setting all elements of matrix to 0
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            coeff[i][j]=0;
        }
    }
    n=n/3;

    //Function Values of Adjacent Polynomials must be equal
    for(i=1;i<n;i++)                                                             
    {
        power=2;
        for(j=0;j<3;j++)
        {
            coeff[2*(i-1)][3*(i-1)+j]=pow(x[i],power);
            coeff[2*(i-1)+1][3*i+j]=pow(x[i],power);
            power--;
        }       

        rhs[2*(i-1)]=y[i];
        rhs[2*(i-1)+1]=y[i]; 
        
    }

    //Function Values at Endpoints(0th and last functions)
    power=2;
    for(j=0;j<3;j++)
    {

        coeff[2*(i-1)][j]=pow(x[0],power);
        rhs[2*(i-1)]=y[0];

        coeff[2*(i-1)+1][3*(n-1)+j]=pow(x[n],power);
        rhs[2*(i-1)+1]=y[n];
        power--;
    }

    i=2*i;
    k=0;
    
    //Matching the derivatives at knots
    for(j=1;j<n;j++,i++,k++)
    {
        printf("%d\n",k);
        coeff[i][3*k]=2*x[j];
        coeff[i][3*k+1]=1;
        coeff[i][3*k+3]=-2*x[j];
        coeff[i][3*k+4]=-1; 
    }

    //a1=0
    coeff[3*n-1][0]=1;
    rhs[3*n-1]=0;

    //Display the Arrays obtained
    for(i=0;i<3*n;i++)
    {
        for(j=0;j<3*n;j++)
        {
            printf("%lf\t",coeff[i][j]);
        }
        printf("%lf\n",rhs[i]);
    }

    n=3*n;
    
    //Do Gauss elimination with the matrices obtained
    Gauss(n,coeff,rhs,result);

    //Display the function to be plotted in Desmos
    for(i=0;i<n/3;i++)
    {
        printf("{%lf<x<%lf:%lfx^2+%lfx+%lf}\n",x[i],x[i+1],result[3*i],result[3*i+1],result[3*i+2]);
    }
}