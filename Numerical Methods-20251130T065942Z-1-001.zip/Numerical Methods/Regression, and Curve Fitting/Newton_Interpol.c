#include <stdio.h>
#include <math.h>

int n;//Takes the degree of the polynomial
void Interpol(int n,double x[n],double y[n]);//Function to do Interpolation


int main()
{    
    printf("Enter the value of n:");
    scanf("%d",&n);
    n++;
    double x[n],y[n];//xi and yi
    
    //Taking input xi and yi
    for(int i=0;i<n;i++)
    {
        printf("Enter x%d:",i);
        scanf("%lf",&x[i]);
        printf("Enter y%d:",i);
        scanf("%lf",&y[i]);
    }
    
    Interpol(n,x,y);
}

//Function to interpolate
void Interpol(int n,double x[n],double y[n])
{
    int i=0,j=0;//Iteration variables
    double fdd[n][n];//To store the finite divided differences

    //Storing 1st column
    for(i=0;i<n;i++)
    {
        fdd[i][0]=y[i];
    }

    //Finding elements of fdd array
    for(j=1;j<n;j++)
    {
        for(i=0;i<n-j;i++)
        {
            fdd[i][j]=(fdd[i+1][j-1]-fdd[i][j-1])/(x[i+j]-x[i]);
        }
    }

    //Displaying the coefficients of the polynomial
    for(i=0,printf("\n");i<n;i++)
    {
        printf("%0.15lf,",fdd[0][i]);
    }
    
}