#include <stdio.h>
#include <math.h>

//Function to do Gauss Elimination to solve for AX=B
void Gauss(int n, double A[n][n], double B[n], double X[n]) 
{
    //Iterate through each row
    for (int i = 0; i < n; i++)
    {
        // Find pivot element
        int pivot = i;
        for (int j = i + 1; j < n; j++) 
        {
            if (fabs(A[j][i]) > fabs(A[pivot][i])) 
            {
                pivot = j;
            }
        }
        
        //Swap the rows
        for (int j = 0; j < n; j++)
        {
            double temp = A[i][j];
            A[i][j] = A[pivot][j];
            A[pivot][j] = temp;
        }
        double temp = B[i];
        B[i] = B[pivot];
        B[pivot] = temp;

        //Do Gauss Elimination
        for (int j = i + 1; j < n; j++) 
        {
            double factor = A[j][i] / A[i][i];
            for (int k = i + 1; k < n; k++) 
            {
                A[j][k] -= factor * A[i][k];
            }
            B[j] -= factor * B[i];
        }
    }
  
    //Back Substitution to find X
    for (int i = n - 1; i >= 0; i--) 
    {
        double sum = 0.0;
        for (int j = i + 1; j < n; j++) 
        {
            sum += A[i][j] * X[j];
        }
        X[i] = (B[i] - sum) / A[i][i];
    }
}

// performing multiple linear regression and printing out the required paramteres
void linear_regression(double* x1,double* x2, double* y, double* result,int n) 
{
    double A[3][3];//Coefficient matrix
    double B[3];//RHS Matrix

    //Setting all elements of the matrices to 0
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            A[i][j]=0;
        }
        B[i]=0;
    }

    //Finding the elements of the coefficient matrix
    for (int i = 0; i < n; i++)
    {
        A[0][0]++;//n
        A[0][1]+=x1[i];//Sum of x1i
        A[0][2]+=x2[i];//Sum of x2i
        A[1][0]+=x1[i];//Sum of x1i
        A[1][1]+=x1[i]*x1[i];//Sum of x1i^2
        A[1][2]+=x1[i]*x2[i];//Sum of x1i*x2i
        A[2][0]+=x2[i];//sum of x2i
        A[2][1]+=x1[i]*x2[i];//Sum of x1i*x2i
        A[2][2]+=x2[i]*x2[i]; //Sum  of x2i^2

        B[0]+=y[i];//Sum of yi
        B[1]+=x1[i]*y[i];//Sum of x1i*yi
        B[2]+=x2[i]*y[i];//Sum of x2i*yi
    }

    //Guass Elimination to solve for a0,a1,a2
    Gauss(3,A,B,result);
}


int main()
{
    int n;//Number of points
    double result[3];//Matrix to store a0,a1,a2
    printf("Enter the number of points:");
    scanf("%d",&n);

    double x1[n],x2[n],y[n];//x1i,x2i and yi

    //Taking input
    for(int i=0;i<n;i++)
    {
        scanf("%lf",&x1[i]);
        scanf("%lf",&x2[i]);
        scanf("%lf",&y[i]);
    }


    linear_regression(x1,x2,y,result,n);
    
    //Display the best fit
    printf("y=%.10lf+%.10lfx1+%lfx2\n",result[0],result[1],result[2]);
    

    //Finding S_r
    double S_r=0;
    for(int i=0;i<n;i++)
    {
        S_r+=pow(y[i]-result[0]-result[1]*x1[i]-result[2]*x2[i],2);
    }

    //Finding the Standard Error
    float std_err=sqrt(S_r/(n-(2+1)));
    printf("The standard Error is %.10lf\n",std_err);

    //Finding S_t
    double S_t=0;
    
    //Finding mean
    double y_avg=0;
    for(int i=0;i<n;i++)
    {
        y_avg+=y[i];
    }
    y_avg=y_avg/n;
 
    for(int i=0;i<n;i++)
    {
        S_t+=pow(y[i]-y_avg,2);
    }

    //Finding r=sqrt((St-Sr)/St)
    printf("The Coefficient of Determination is %.10lf",sqrt((S_t-S_r)/S_t));
    
}