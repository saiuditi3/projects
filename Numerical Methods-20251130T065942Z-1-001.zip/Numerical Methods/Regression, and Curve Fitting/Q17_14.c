#include <stdio.h>
#include <math.h>

//Linear Regression using the given x and y
void linear_regression(double* x, double* y, double* result,int n) 
{
    double sum_x = 0;//sum of xi
    double sum_x_square = 0;//sum of xi^2
    double sum_y = 0;//sum of y
    double sum_xy = 0;//sum of xiyi

    //Finding the Sums
    for (int i = 0; i < n; i++)
    {
        sum_x += x[i];
        sum_x_square += pow(x[i], 2);
        sum_y += y[i];
        sum_xy += x[i] * y[i];
    }

    //Finding coefficients a1 and a0
    double a1 = (sum_xy * n - sum_y * sum_x)/(n * sum_x_square - sum_x * sum_x);
    double a0 = (sum_y - sum_x * a1) / n;

    //Printing out the best fit line after performing linear regression
    //The y in this equation is sqrt(y) and x is 1/sqrt(x)
    printf("The best fit line is:\ny = %.10lf x + %.10lf\n", a1, a0);

    //Storing the coefficients in array result
    result[0]=a0;
    result[1]=a1;
}


int main()
{
    int n;//Number of elements
    double result[2];//Matrix to store a0 and a1 
    printf("Enter the number of points:");
    scanf("%d",&n);

    double x[n],y[n];//xi and yi

    //Storing 1/sqrt(x) and sqrt(y)
    for(int i=0;i<n;i++)
    {
        scanf("%lf",&x[i]);
        x[i]=1/(sqrt(x[i]));

        scanf("%lf",&y[i]);
        y[i]=sqrt(y[i]);
    }

    linear_regression(x,y,result,n);
    
    //Displaying the values of a and b using the relations b=1/a0 and a=a1*b
    printf("a:%.10lf\nb:%.10lf\n",result[1]/result[0],(1/result[0]));

    //Finding the value of y at x=1.6
    double y_req=pow(result[1]*pow(1.6,-0.5)+result[0],2);
    printf("The value of y at x=1.6 is %0.10lf",y_req);

}