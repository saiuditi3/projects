#include<stdio.h>
#include<math.h>
#include<stdlib.h>

#define PI 3.14159265358979323846

int main()
{
    //Files to store Estimate of Pi and Error
    FILE *pihat_val=NULL;
    FILE *pihat_err=NULL;
    pihat_val=fopen("Q1_pihat.txt","w");//File to Write Value of Estimate of Pi
    pihat_err=fopen("Q1_pihaterror.txt","w");//File to write Errors in estimation of Pi
    
    //Initialising Variables
    int n,//Total number of random points taken
    n_arc;//Number of points inside quarter Circle

    float x,y,//Random Point (x,y)
    pi_hat,//Estimate of Pi
    pi_hat_err;//Error in estimate of Pi

    //Runs from j=1 to 10^9
    for(int j=0;j<10;j++)
    {   
        //set seed for every estimation of Pi
        srand(1122022);
        n=pow(10,j);
        n_arc=0;

        //Loop to count the number of points inside the arc
        for(int i=1;i<=n;i++)
        {
            //Generating Random Numbers in (0,1])
            x=(float)rand()/RAND_MAX;
            y=(float)rand()/RAND_MAX;
            
            //Increment n_arc if the point (x,y) is inside the quarter circle
            if(x*x+y*y<=1)
            {
                n_arc++;
            }
        }

        //Writing Values of estimates of Pi to File
        pi_hat=((float)n_arc/n)*4;
        fprintf(pihat_val,"%d\t%f\n",j,pi_hat);
        
        //Writing Values of Errors to File
        pi_hat_err=fabs((pi_hat-PI))/PI*100;
        fprintf(pihat_err,"%d\t%f\n",j,pi_hat_err);
    }
    
}