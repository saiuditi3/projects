#include<stdio.h>
#include<math.h>
#include<stdlib.h>

#define PI 3.14159265358979323846

int main()
{
    //filename of the file to write data to
    char *filename;
    
    //initialising variables
    int n,//Total number of random points taken
    n_arc;//Number of points inside quarter Circle

    float x,y,//Random Point (x,y)
    pihat,//Estimate of Pi
    writeval;//Value to be written to file

    //Loop to find estimates of pi for n=10^2,10^4 and 10^6
    for(int i=2;i<=6;i+=2)
    {
        //Set a different seed for each i
        srand(i);
        
        //Changing the filename to the file in which the data has to be written, and setting the pointer accordingly
        asprintf(&filename, "histogram-10_%d.txt", i);
        FILE *histfile=fopen(filename,"w");
        n=pow(10,i);

        //Calculating 100000 values of estimate of pi
        for(int j=0;j<100000;j++)
        {     
            n_arc=0;

            //Count the number of points (x,y) inside the quarter circle
            for(int k=1;k<=n;k++)
            {
                //Generating Random point (x,y)
                x=(float)rand()/RAND_MAX;
                y=(float)rand()/RAND_MAX;
                
                //Increment n_arc if the point (x,y) is inside the quarter circle
                if(x*x+y*y<=1)
                {
                    n_arc++;
                }
            }
            
            //Calculates pi and sqrt(n)*(pihat-PI); write sqrt(n)*(pihat-PI) to the right file
            pihat=((float)n_arc/n)*4;
            writeval=sqrt(n)*(pihat-PI);
            fprintf(histfile,"%f\n",writeval);
        }
    }
}