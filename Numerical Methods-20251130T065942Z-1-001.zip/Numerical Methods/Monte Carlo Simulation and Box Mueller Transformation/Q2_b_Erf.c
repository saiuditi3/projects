#include<stdio.h>
#include<math.h>
#include<stdlib.h>

int main()
{
    float x;//Declaring X
    int j=0,//Loop Counter
    erf1=0,//Erf(1) Counter
    erf2=0;//Erf(2) Counter

    //Variables to Store U1 and U2 for each iteration
    float U1;
    float U2;

    //Function to count erf1 and erf2
    for(j=1;j<=pow(10,5);j++)
    {
        //Generate Random Numbers in [0,1) and assign those to U1 and U2
        U1=(float)rand()/RAND_MAX;
        U2=(float)rand()/RAND_MAX;

        //Calculate x
        x=sqrt(-2*log(U1))*cos(2*M_PI*U2);
        
        //Increment erf1 if x<=1
        if(x<=1)
        {
            erf1++;
        }
        
        //Increment erf2 if x<=2
        if(x<=2)
        {
            erf2++;
        }
    }
    
    //Calculate Erf(1) and Erf(2) and display them.
    printf("The Value of erf(1) is: %f\n",(float)erf1/pow(10,5));
    printf("The Value of erf(2) is: %f",(float)erf2/pow(10,5));
}