#include<stdio.h>
#include<math.h>
#include<stdlib.h>

int main()
{
    char *filename;//Filename of the CSV File to which the data is to be written
    FILE *csvfile=NULL;//Pointer to the File
    
    float x;//Defining X
    int j=0;//Loop Counter

    //Loop to obtain X for 10,100,1000,10000
    for(int i=1;i<=4;i++)
    {
        //Change Filename to the appropriate filename and opening the file
        asprintf(&filename, "Q2_a_x_%d.csv", (int)pow(10,i));
        csvfile=fopen(filename,"w");

        //Arrays Containing Random Variables
        float U1[(int)pow(10,i)];
        float U2[(int)pow(10,i)];
    
        //Setting the Seed
        srand(0);

        //Inserting Random Number in [01) to U1
        for(j=1;j<=pow(10,i);j++)
        {
            U1[j]=(float)rand()/RAND_MAX;
        }
        
        for(j=1;j<=pow(10,i);j++)
        {
            //Inserting Random Number in [01) to U2
            U2[j]=(float)rand()/RAND_MAX;

            //Calculating X and writing its Value to appropriate File
            x=sqrt(-2*log(U1[j]))*cos(2*M_PI*U2[j]);
            fprintf(csvfile,"%f\n",x);
        }  

    }
}