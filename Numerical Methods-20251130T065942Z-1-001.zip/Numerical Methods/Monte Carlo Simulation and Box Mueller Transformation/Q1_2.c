#include<stdio.h>
#include<math.h>
#include<stdlib.h>

#define PI 3.14159265358979323846

int main()
{
    //Initialising Variables
    float sum=0,//Sum of the Series
    err;//Error in estimation of Pi
    
    //Loop to estimate Pi using Madhavan Series
    for(int i=2;i<=6;i++)
    {
        sum=0;//Resets sum for each iteration
        
        //Loop to add the terms of the series
        for(float j=0;j<pow(10,i);j++)
        {
            sum+=(pow(-1,j)*4)/(2*j+1);
        }
        
        //Calculate the error and display it on the screen
        err=(fabs(sum-PI)/PI)*100;
        printf("%d\t%f\t%f\n",i,sum,err);
    }
}