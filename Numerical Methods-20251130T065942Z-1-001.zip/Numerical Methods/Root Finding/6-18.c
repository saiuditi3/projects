#include<stdio.h>
#include<math.h>

//Constants in the Function
float delta=0.5;float V=1000000,Q=100000,W=1000000,c=4,k=0.25;

//Variable to Store the Error
float error;

//Function to calculate the output of the Function Given in the Question
float f(float c)
{
    float sum;
    sum=W-Q*c-k*V*sqrt(c);
    return sum;
}

//Function that finds the root by modified secant method
float mod_secant(float initialguess)
{
    //File to write the errors to
    FILE *fp = NULL;
    fp = fopen("6-18_Error.txt","w");

    float x_new=0;
    float x_old=initialguess;

    for(int i=0;i<=3;i++)
    {
        //Update x_old and then x_new after
        x_old=x_new;
        x_new = x_old - (delta*f(x_old))/(f(x_old+delta)-f(x_old));

        error=((x_new-x_old)/x_new)*100;
        
        if (error<0)
        {
            error=-error;
        }

        //Write the error of ith iteration
        if(i!=0)
        {
        fprintf(fp,"%d\t%f\n",i,error);
        }
    }
    
    //Returning the final root after 3 iterations
    return x_new;
}

int main()
{
    //Calling mod_secant with the starting value of c=4
    float out=mod_secant(4.0);

    //Display output to the screen
    printf("The Root is: %f\n",out);
    printf("Error after 3 iterations is: %f %%",error);


}
