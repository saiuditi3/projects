#include<stdio.h>
#include<math.h>

//Constants of the function
const double w0=2500.0,E=50000000.0,I=30000.0,L=600.0;

double error; int iter=0;



//Evaluates and Returns the Value of the Polynomial at x
double polyEvaluate(double x){
    double val= 0.0;
    val=(w0*(-5.0*pow(x,4)+6*600.0*600.0*pow(x,2)-600.0*600.0*600.0*600.0))/(120*E*I*L);
    return val;
}

//Function to calculate the root by bisection method
double bisection(double xl, double xu)
{
    double mid = (xl+xu)*0.5;

    //Value of Function at midpoint, Lower Limit and Upper Limit
    double fMid = polyEvaluate(mid);
    double fxl = polyEvaluate(xl);
    double fxu = polyEvaluate(xu);
    
    error=(xu-xl)/(xu+xl)*100;
    
    //Write errors to file    
    FILE *fp = NULL;
    fp=fopen("5-20_Error.txt","a");
    fprintf(fp,"%d\t%f\n",iter,error);

    iter++;

    //Exit Recursion if xl and xu are very close
    if(abs(xu-xl) < 1e-8){
        return mid;
    }
    
    //Conditions to sawp xl, xu and mid according to the values of f at the points
    if(fMid*fxl < 0)
    {
        return bisection(xl, mid);
    } 
    
    else if (fMid*fxu < 0)
    {
        return bisection(mid, xu);
    } 
   
    //Return mid if the value of the function at mid is 0
    else  
    {
        return mid;
    }


}


int main()
{   
    float root=bisection(250,300);
    printf("The root of the Equation is: %f",root);
    float val=-w0*(-1.0*pow(root,5)+2*600.0*600.0*pow(root,3)-600.0*600.0*600.0*600.0*root)/(120*E*I*L);
    printf("\nThe maximum deflection is: %f",val);

}