#include<stdio.h>
#include<math.h>

//equation is: Ps-1.2Pc=0

//The constants in the equation
double Pu_max=75000.0, ku=0.045,Pu_min=100000.0,Ps_max=300000,P0=10000.0,ks=0.08;

//Initialisation of Variables
double error,errorthreshold;
int iter=0;
int iter_limit;

//Function to Evaluate Pu
double Pu(double t)
{
    double sum=0.0;
    sum=Pu_max*exp(-ku*t) + Pu_min;
    return sum;
}

//Function to Evaluate Ps
double Ps(double t)
{
    double sum=0.0;
    sum= Ps_max/(1+(((Ps_max/P0) - 1)*exp(-ks*t)));
    return sum;

}

//Function to find the root using False Position Method
double falseposition(double xl, double xu)
{
    //File to write percent relative errors
    FILE *fp=NULL;
    fp=fopen("5-22_Error.txt","w");

    double xr=0;

    if (xr==0)
    {
        xr=xl;
    }

    //while loop that runs till the terminate conditions are reached
    while(!(error<errorthreshold || iter>=iter_limit))
    {
        //Evaluate f(t)=(Ps-Pu)(t) for t=xl,xu
        double f_xu=Ps(xu)-1.2*(Pu(xu));double f_xl=Ps(xl)-1.2*(Pu(xl));

        //Calculate xr
        xr=xu- (f_xu*(xl-xu))/(f_xl-f_xu);

        //Evaluate f(t)=(Ps-Pu)(t) for t=xl,xu
        double f_xr=Ps(xr)-1.2*(Pu(xr));

        if(f_xr*f_xu<0)
        {
            xl=xr;
        }

        //Updating xu and xl:

        else if(f_xr*f_xl<0)
        {
            xu=xr;
        }

        else
        {
            break;
        }


        //Calculating Percent Relative Error
        error=(xu-xl)/(xu+xl)*100;
        
        if(error<0)
        {
            error=-error;
        }

        iter++;

        //Write the number of iterations and the value of percent relative error
        fprintf(fp,"%d\t%lf\n",iter,error);


        //Exit out of the loop and print the value of the root
        if(error<errorthreshold || iter>=iter_limit)
        {
            printf("\nThe Root is:%lf",xr);
            break;
        }
        
        
    }
        
}

int main()
{
    double xl,xu;
    
    //Get Estimated Lower Limit and Upper Limit, Error Threshold and Iteration Limit as User Input
    printf("Enter the Estimated Lower Limit:");
    scanf("%lf",&xl);

    printf("Enter the Estimated Upper Limit:");
    scanf("%lf",&xu);

    printf("Enter the Error Threshold:");
    scanf("%lf",&errorthreshold);

    printf("Enter the Limit to Number of Iterations:");
    scanf("%d",&iter_limit);

    error=errorthreshold+1;
    falseposition(xl,xu);
}