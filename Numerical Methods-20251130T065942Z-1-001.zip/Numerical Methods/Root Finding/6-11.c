#include <stdio.h>
#include <math.h>

//Error threshold
const double threshold = 0.05;

//Flag to check if Newton Raphson has begun diverging
int divergeflag=0;

double newtonRaphson(double x)
{
    //Calculating the value of the function and its derivative at x.
    double f = (4.0-x)*exp(-0.5*x) - 2.0;
    double fDeriv = exp(-0.5*x)*(0.5*x - 3.0);

    //Finding xi+1 from xi, value of function at xi and derivative at xi
    double xNew = x - (f/fDeriv);

    //Finding Error
    double err = (xNew - x)/xNew*100.0;
    if(err<0)
    {
        err=-err;
    }

    //Exit the function if xNew gets undefined   
    if(xNew!=xNew)
    {
        divergeflag=1;
        return x;
    }
 
    //Exit the function if error is lower than threshold
    if(err < threshold)
    {
        return xNew;
    } 

    //Call the function again if exit conditions are not satisfied
    else 
    {
        return newtonRaphson(xNew);
    }

}


//Displays the root if newton-raphson doesn't diverge and displays that it diverges if it does
int display(double x)
{
    if(divergeflag==0)
    {
        printf("The Root is: %f\n\n",x);
    }

    else
    {
        printf("Newton-Raphson diverges \n\n");
    }
}


int main(){

    double x;
    
    //Newton-Raphson with an initial guess of 2
    x=newtonRaphson(2.0);
    printf("For an initial guess of 2.0:\n");
    display(x);

    //Newton-Raphson with an initial guess of 6
    x=newtonRaphson(6.0);
    printf("For an initial guess of 6.0:\n");
    display(x);

    //Newton-Raphson with an initial guess of 8
    x=newtonRaphson(8.0);
    printf("For an initial guess of 8.0:\n");
    display(x);

    return 0;

}