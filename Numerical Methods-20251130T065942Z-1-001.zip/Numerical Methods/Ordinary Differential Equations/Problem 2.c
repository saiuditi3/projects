#include <stdio.h>
#include <math.h>

double R;

//First function: sqrt(1+x^2)

//Evaluates Function:
double f_a(double x)
{
    return sqrt(1+pow(x+1,2));
}

//First Derivative
double f_a_1(double x)
{
    return x/sqrt(1+pow(x+1,2));
}

//Second Derivative
double f_a_2(double x)
{
    return 1/pow(1+(x+1)*(x+1),3/2);
}


//Second function: x^4

//Value of f(x)
double f_b(double x)
{
    return pow(x+1,4);
}

//First Derivative
double f_b_1(double x)
{
    return 4*pow(x+1,3);
}

//Second Derivative
double f_b_2(double x)
{
    return 12*pow(x+1,2);
}

//Function to use the Golden- Section Search
double Golden(double x_l,double x_u,double (*f)(),double e_s)
{
    double x_1=x_l+R*(x_u-x_l),//First point between xl and xu
    x_2=x_u-R*(x_u-x_l),//Second point between xl and xu
    err,//Error
    x_opt,//Optimum value of x
    f_x1=-f(x_1),//Value of f(x1)
    f_x2=-f(x_2);//Value of f(x2)

    //Removing intervals based on values of f:
    if(f_x1>f_x2)
    {
        x_opt=x_1;
        err=(((1-R)*fabs(x_u-x_l))/x_opt)*100;//Calculating Error
        
        if(err>e_s)
        {
            return Golden(x_opt,x_u,f,e_s);//Recursively Calling the Function with new arguments
        }
        return x_opt;//Return the Optimum value when err<threshold
    }

    else
    {
        x_opt=x_2;
        err=(((1-R)*fabs(x_u-x_l))/x_opt)*100;//Calculating Error
        
        if(err>e_s)
        {
            return Golden(x_l,x_opt,f,e_s);//Recursively Calling the Function with new arguments
        }
        return x_opt;//Return the Optimum value when err<threshold
    }
}

//Function for Parabolic Interpolation
double Parabolic(double x_0,double x_1,double x_2,double (*f)(),int n)
{
    double x_3;//Point at which slope=0 for the quadratic

    //Iterate n times
    for(int i=0;i<n;i++)
    {
        x_3=(f(x_0)*(x_1*x_1-x_2*x_2)+f(x_1)*(x_2*x_2-x_0*x_0)+f(x_2)*(x_0*x_0-x_1*x_1))/(2*(f(x_0)*(x_1-x_2)+f(x_1)*(x_2-x_0)+f(x_2)*(x_0-x_1)));//Calculate x3
    }
    return x_3;
}

//Function for Newton's Method
double Newton(double x,double (*f)(),double (*f_1)(),double (*f_2)(),double e_s, int count)//count is the number of iterations
{
    double x_new=x-f_1(x)/f_2(x),//Calculate x_new from x_old
    err=fabs((x_new-x)*100/x);//Calculate Error

    if(err>e_s && count<=500)
    {
        count++;
        return Newton(x_new,f,f_1,f_2,e_s,count);//Recursively Calling the Function
    }

    return x_new;//Return x_new when err<threshold error
}

//Function for Two-Thirds Search
double Two_thirds(double x_l,double x_u,double (*f)(),double e_s)
{
    double x_1,//First point in between x_u and x_l
    x_2,//Second point between x_u and x_l
    err,//Error
    x_opt;//Optimum x

    do
    {
        //Finding x1 and x2
        x_1 = x_l +(2.0/3)*(x_u - x_l);
        x_2 = x_u -(2.0/3)*(x_u - x_l);

        //Removing intervals based on values of f
        if(f(x_1)<f(x_2))
        {
            x_l = x_2;
            x_opt = x_1;
        }

        if(f(x_2)<f(x_1))
        {
            x_u = x_1;
            x_opt = x_2;
        }

        err = fabs((1.0-(float)(2/3))*((x_u - x_l)/x_opt)*100);//Calculating error
    }while(err>e_s);

    return x_opt;

}

int main()
{
    R=(sqrt(5)-1)/2;//Golden Ratio
    float golden,//Store the value of x for golden section search
    two_thirds,//Store the value of x for two-third search
    parabolic,//Store the value of x for Parabolic Interpolation
    newton;//Store the value of x for Newon's Method

    double (*f)(double);//Pointer to function
    double (*f_1)(double);//Pointer to derivative of function
    double (*f_2)(double);//Pointer to second derivative of function
    
    //Displaying Results for sqrt(1+x^4)

    f=f_a;f_1=f_a_1,f_2=f_a_2;//Setting the pointers to first function
    printf("sqrt(1+x^2)\n");

    //Display Results for Newton's Method
    printf("\nNewton's Method:\n");
    newton=Newton(0.9,f,f_1,f_2,1,0);//Newton's Method with x0=0.9, threshold error=1%
    if(newton!=newton)//Check if newton is nan
    {
        printf("The root doesn't converge for Newton's Method\n");
    }
    else
    {
        printf("The minimum of the function is %0.10lf at x=%0.10lf\n",f(newton-1),newton);
    }   

    newton=Newton(1.1,f,f_1,f_2,1,0);//Newton's Method with x0=0.9, threshold error=1%
    if(newton!=newton)//Check if newton is nan
    {
        printf("The root doesn't converge for Newton's Method\n");
    }
    else
    {
        printf("The minimum of the function is %0.10lf at x=%0.10lf\n",f(newton-1),newton);
    } 

    //Golden Section Search with endpoints -2 and 4, error threshold 1%
    printf("\nGolden-Section Search:\n");
    golden=Golden(-2,4,f,1);
    printf("The minimum of the function is %0.10lf at x=%0.10lf\n",f(golden),golden+1);
    
    //Two-thirds search with endpoints -2 and 4, error threshold 1%
    printf("\nTwo-Thirds Search:\n");
    two_thirds=Two_thirds(-2,4,f,0.01);
    printf("The minimum of the function is %0.10lf at x=%0.10lf\n",f(two_thirds),two_thirds+1);
    
    //Parabolic Interpolation with initial guesses -2,0.5,2.5 and 20 iterations
    printf("\nParabolic Interpolation:\n");
    parabolic=Parabolic(-2,0.5,2.5,f,20);
    printf("The minimum of the function is %0.10lf at x=%0.10lf\n",f(parabolic),parabolic+1);
    
     
    //Displaying results for x^4

    f=f_b;f_1=f_b_1,f_2=f_b_2;//Settig the pointers to the corresponding functions
    printf("\n\nx^4\n");

    //Golden Section Search with endpoints -2 and 4, error threshold 1%
    printf("Golden-Section Search:\n");
    golden=Golden(-2,4,f,1);
    printf("The minimum of the function is %0.10lf at x=%0.10lf\n",f(golden),golden+1);
    
    //Two-thirds search with endpoints -2 and 4, error threshold 1%
    printf("\nTwo-Thirds Search:\n");
    two_thirds=Two_thirds(-2,4,f,1);
    printf("The minimum of the function is %0.10lf at x=%0.10lf\n",f(two_thirds),two_thirds+1);
    
    //Parabolic Interpolation with initial guesses -2,0.5,2.5 and 20 iterations
    printf("\nParabolic Interpolation:\n");
    parabolic=Parabolic(-2,0.5,2,f,20);
    printf("The minimum of the function is %0.10lf at x=%0.10lf\n",f(parabolic),parabolic+1);
    
    //Display Results for Newton's Method and x0=0.9, error threshold=1%
    printf("\nNewton's Method:\n");
    newton=Newton(0.9,f,f_1,f_2,1,0);
    if(newton!=newton)//Check if newton is nan
    {
        printf("The root doesn't converge for Newton's Method\n");
    }
    else
    {
        printf("The minimum of the function is %0.10lf at x=%0.10lf\n",f(newton-1),newton);
    }   

    //Newton's method with x0=1.1
    newton=Newton(1.1,f,f_1,f_2,1,0);
    if(newton!=newton)//Check if newton is nan
    {
        printf("The root doesn't converge for Newton's Method\n");
    }
    else
    {
        printf("The minimum of the function is %0.10lf at x=%0.10lf\n",f(newton-1),newton);
    }   

}