#include <stdio.h>
#include <math.h>

//Defining constants 
float R,
theta=50*M_PI/180,
g=9.81,
v_0=25,
y_0=1;


//Value of f(x)
double f(double x)
{
    return tan(theta)*x-(g/(2*v_0*v_0*cos(theta)*cos(theta)))*pow(x,2)+y_0;
}

//Function to use the Golden- Section Search
double Golden(double x_l,double x_u,double e_s)
{
    double x_1=x_l+R*(x_u-x_l),//First point between xl and xu
    x_2=x_u-R*(x_u-x_l),//Second point between xl and xu
    err,//Error
    x_opt,//Optimum value of x
    f_x1=f(x_1),//Value of f(x1)
    f_x2=f(x_2);//Value of f(x2)

    //Removing intervals based on values of f:
    if(f_x1>f_x2)
    {
        x_opt=x_1;
        err=(((1-R)*fabs((x_u-x_l)/x_opt)))*100;//Calculating Error
        
        if(err>e_s)
        {
            return Golden(x_2,x_u,e_s);//Recursively Calling the Function with new arguments
        }
        return x_opt;//Return the Optimum value when err<threshold
    }


    else
    {
        x_opt=x_2;
        err=(((1-R)*fabs((x_u-x_l)/x_opt)))*100;//Calculating Error
        
        if(err>e_s)
        {
            return Golden(x_l,x_1,e_s);//Recursively Calling the Function with new arguments
        }
        return x_opt;//Return the Optimum value when err<threshold
    }
}

int main()
{
    R=(sqrt(5)-1)/2;//Defining Golden Ratio
    float golden;//Variable to store the value returned by function

    //Display Results
    printf("Golden-Section Search:\n");
    golden=Golden(0,60,1);//Golden Ratio Search with endpoints 0,60 and error threshold 1%
    printf("The maximum height is %0.10lf at x=%0.10lf\n",f(golden),golden);
}