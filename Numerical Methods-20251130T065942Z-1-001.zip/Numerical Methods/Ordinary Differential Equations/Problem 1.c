#include <stdio.h>
#include <math.h>

float R;//Value of Golden Ratio

//Evaluate f(x)
double f(double x)
{
    return 4*x-1.8*pow(x,2)+1.2*pow(x,3)-0.3*pow(x,4);
}

//First Derivative of f(x)
double f_1(double x)
{
    return 4-3.6*x+3.6*pow(x,2)-1.2*pow(x,3);
}

//Second Derivative of f(x)
double f_2(double x)
{
    return -3.6+7.2*x-3.6*pow(x,2);
}

//Function to use the Golden- Section Search
double Golden(double x_l,double x_u,double e_s)
{
    double x_1=x_l+R*(x_u-x_l),//First point between xl and xu
    x_2=x_u-R*(x_u-x_l),//Second point between xl and xu
    err,//Error
    x_opt,//Optimum value of x
    f_x1=f(x_1),//Value of f(x1)
    f_x2=f(x_2);//Value of f(x2)

    //Removing intervals based on values of f:
    if(f_x1>f_x2)
    {
        x_opt=x_1;
        err=(((1-R)*fabs((x_u-x_l)/x_opt)))*100;//Calculating Error
        
        if(err>e_s)
        {
            return Golden(x_2,x_u,e_s);//Recursively Calling the Function with new arguments
        }
        return x_opt;//Return the Optimum value when err<threshold
    }


    else
    {
        x_opt=x_2;
        err=(((1-R)*fabs((x_u-x_l)/x_opt)))*100;//Calculating Error
        
        if(err>e_s)
        {
            return Golden(x_l,x_1,e_s);//Recursively Calling the Function with new arguments
        }
        return x_opt;//Return the Optimum value when err<threshold
    }
}

//Function for Parabolic Interpolation
double Parabolic(double x_0,double x_1,double x_2,int n)
{
    double x_3;//Point at which slope=0 for the quadratic
    
    //Iterate n times
    for(int i=0;i<n;i++)
    {
        x_3=(f(x_0)*(x_1*x_1-x_2*x_2)+f(x_1)*(x_2*x_2-x_0*x_0)+f(x_2)*(x_0*x_0-x_1*x_1))/(2*(f(x_0)*(x_1-x_2)+f(x_1)*(x_2-x_0)+f(x_2)*(x_0-x_1)));
        x_0=x_1;x_1=x_2;x_2=x_3;//Calculate x3
    }
    return x_3;
}

//Function for Newton's Method
double Newton(double x,double e_s, int count)//count is the number of iterations
{
    double x_new=x-f_1(x)/f_2(x),//Calculate x_new from x_old
    err=fabs((x_new-x)*100/x);//Calculate Error

    if(err>e_s && count<=500)
    {
        count++;
        return Newton(x_new,e_s,count);//Recursively Calling the Function
    }

    return x_new;//Return x_new when err<threshold error
}

//Function for Two-Thirds Search
double Two_thirds(double x_l,double x_u,double e_s)
{
    double x_1,//First point in between x_u and x_l
    x_2,//Second point between x_u and x_l
    err,//Error
    x_opt;//Optimum x

    do
    {
        //Finding x1 and x2
        x_1 = x_l +(2.0/3)*(x_u - x_l);
        x_2 = x_u -(2.0/3)*(x_u - x_l);

        //Removing intervals based on values of f
        if(f(x_1)>f(x_2))
        {
            x_l = x_2;
            x_opt = x_1;
        }

        if(f(x_2)>f(x_1))
        {
            x_u = x_1;
            x_opt = x_2;
        }

        err = fabs((1.0-(float)(2/3))*((x_u - x_l)/x_opt)*100);//Calculating error
    }while(err>e_s);

    return x_opt;

}


int main()
{
    R=(sqrt(5)-1)/2;//Golden Ratio
    float golden,//Store the value of x for golden section search
    two_thirds,//Store the value of x for two-third search
    parabolic,//Store the value of x for Parabolic Interpolation
    newton;//Store the value of x for Newon's Method

    //Displaying the Results for different methods:

    //Golden Section Search with endpoints -2 and 4, error threshold 1%
    printf("Golden-Section Search:\n");
    golden=Golden(-2,4,1);
    printf("The maximum of the function is %0.10lf at x=%0.10lf\n",f(golden),golden);
    
    //Two-thirds search with endpoints -2 and 4, error threshold 1%
    printf("\nTwo-Thirds Search:\n");
    two_thirds=Two_thirds(-2,4,1);
    printf("The maximum of the function is %0.10lf at x=%0.10lf\n",f(two_thirds),two_thirds);
    
    //Parabolic Interpolation with initial guesses 1.75,2,2.5 and 4 iterations
    printf("\nParabolic Interpolation:\n");
    parabolic=Parabolic(1.75,2,2.5,4);
    printf("The maximum of the function is %0.10lf at x=%0.10lf\n",f(parabolic),parabolic);
    
    //Newton's Method with x0=3, threshold error=1%
    printf("\nNewton's Method:\n");
    newton=Newton(3,1,0);
    if(newton!=newton)//Checking if newton is nan
    {
        printf("The root doesn't converge for Newton's Method");
    }
    else
    {
        printf("The maximum of the function is %0.10lf at x=%0.10lf",f(newton),newton);
    }

}