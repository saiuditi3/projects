#include <stdio.h>
#include <math.h>

//Number of nodes in the graph
#define n 6

/*
Structure of the Graph Given
dist[i][j] is the distance from j to i
*/
float dist[n][n]=
{
    {0,INFINITY,INFINITY,INFINITY,INFINITY,INFINITY},
    {1.5,INFINITY,INFINITY,2.3,INFINITY,INFINITY},
    {INFINITY,1.1,0,4.5,INFINITY,INFINITY},
    {INFINITY,INFINITY,INFINITY,0,INFINITY,INFINITY},
    {INFINITY,INFINITY,3.0,INFINITY,0,6.5},
    {0.7,INFINITY,INFINITY,INFINITY,INFINITY,0}
};


//Order in which Nodes are visited
int visited_order[n];

//Shortest Distance from Source to ith node
float dist_result[n];

//i_th row is the path to i_th node
float paths[n][n];

//Check if a node has already been visited
float alreadyvisited(int visited_order[],int k)
{
    for(int i=0;i<n;i++)
    {
        if(visited_order[i]==k){return 1;}
    }
    return 0;
}

void initialize()
{
    for(int i=0;i<n;i++)
    {
        //Setting all values of visited order to 0
        visited_order[i]=0;

        //Setting all Distances to INFINITY
        dist_result[i]=INFINITY;
        
        //Setting all values of the paths taken to -1
        for(int j=0;j<n;j++)
        {
            paths[i][j]=-1;
        }
    }
}

//Implements Dijkstra's Algorithm
void Dijkstra(int src)
{
    initialize();
    int present=src;//Node from which distances are calculated at present iteration; initially set to source
    dist_result[present]=0;//Set distance to source as 0

    //Iterate through n nodes
    for(int i=0;i<n;i++)
    {
        float min=INFINITY,//Minimum distance from a node
        min_node=INFINITY;//Node to which distance is minimum

        //Iterate through remaining nodes
        for(int k=0;k<n;k++)
        {
            //Go to all unvisited nodes only
            if(k!=present && !alreadyvisited(visited_order,k))
            {                
                //Finding the Nearest Node to present
                if(dist[k][present]<=min)
                {
                    min_node=k;
                    min=dist[k][present];
                }

                //Update distance and path
                if(dist_result[present]+dist[k][present]<dist_result[k])
                {
                    
                    if(dist_result[k]==INFINITY)
                    {
                        dist_result[k]=0;
                    }

                    //Update the path for k_th node
                    for(int j=0;j<n;j++)
                    {
                        if(paths[present][j]==-1)
                        {
                            paths[k][j]=present;//Add present node at the end of path
                            break;
                        }
                        paths[k][j]=paths[present][j];//Copy path to present

                    }
                    //Update the value of distance
                    dist_result[k]=dist_result[present]+dist[k][present];
                    
                }
            }
        }
        
        //Updating the order of Visits
        visited_order[i]=present;

        //Updating the present node to the node with least distance
        present=min_node;
    }


    //Displaying Results
    
    //Display the order in which nodes are visited
    printf("The nodes visited were:\n");
    for(int j=0;j<n-1;j++)
    {
        printf("%d->",(int)visited_order[j]+1);
        if(j==n-2)
        {
            printf("%d\n\n",(int)visited_order[n-1]+1);
        }
    }
    
    //Display Distance to each node from source
    printf("\nDistances to nodes from Node %d are:\nNode  Distance\n",src+1);
    for(int j=0;j<n;j++)
    {
        printf("%d     %f\n",j+1,dist_result[j]);
    }printf("\n\n");
    
    //Display the Paths taken to each node
    for(int i=0;i<n;i++)
    {
        int j=0;
        printf("Path to Node %d:\n",(int)i+1);
        if(dist_result[i]==INFINITY)
        {
            printf("No Path Available\n\n");continue;
        }

        for(int j=0;j<n;j++)
        {
            if(paths[i][j]<-1)
            {
                printf("No Path Available");
                break;
            }
            if(paths[i][j]!=-1)
            {
            printf("%d->",(int)paths[i][j]+1);
            }
        }printf("%d\n\n",i+1);

    }
}

//Implements Bellman-Ford Algorithm
void Bellman_Ford(int src)
{
    initialize();
    int present=src;//Node from which distances are calculated at present iteration; initially set to source
    dist_result[present]=0;//Set distance to source as 0

    //n-1 iterations
    for(int x=0;x<n-1;x++)
    {
        //Iterating through each node
        for(present=0;present<n;present++)
        {
            //Iterate through remaining nodes
            for(int k=0;k<n;k++)
            {
                //Go to all unvisited nodes only
                if(k!=present)
                {
                    //Update distance and path
                    if(dist_result[present]+dist[k][present]<dist_result[k])
                    {
                        
                        if(dist_result[k]==INFINITY)
                        {
                            dist_result[k]=0;
                        }

                        //Update the path for k_th node
                        for(int j=0;j<n;j++)
                        {
                            if(paths[present][j]==-1)
                            {
                                paths[k][j]=present;//Add present node at the end of path
                                break;
                            }
                            paths[k][j]=paths[present][j];//Copy path to present

                        }
                        //Update the value of distance
                        dist_result[k]=dist_result[present]+dist[k][present];
                        
                    }
                }
            }
            
        }
    }


    //Displaying Results
    
    //Display Distance to each node from source
    printf("\nDistances to nodes from Node %d are:\nNode  Distance\n",src+1);
    for(int j=0;j<n;j++)
    {
        printf("%d     %f\n",j+1,dist_result[j]);
    }printf("\n\n");
    
    //Display the Paths taken to each node
    for(int i=0;i<n;i++)
    {
        int j=0;
        printf("Path to Node %d:\n",(int)i+1);
        if(dist_result[i]==INFINITY)
        {
            printf("No Path Available\n\n");continue;
        }

        for(int j=0;j<n;j++)
        {
            if(paths[i][j]<-1)
            {
                printf("No Path Available");
                break;
            }

            if(paths[i][j]!=-1)
            {
            printf("%d->",(int)paths[i][j]+1);
            }
        }printf("%d\n\n",i+1);

    }
}

//Main Function
int main()
{    
    printf("For Source Node 4:\n\n");
    
    //Calling the Dijkstra's Algorithm and Bellman- Ford Algorithm Function
    printf("\n\nDijkstra's Algorithm:\n\n");
    Dijkstra(3);
    printf("\n\nBellman- Ford Algorithm:\n\n");
    Bellman_Ford(3);
    printf("\n\n");
    

    printf("For Source Node 1:\n\n");
    
    //Calling the Dijkstra's Algorithm and Bellman- Ford Algorithm Function
    printf("\n\nDijkstra's Algorithm:\n\n");
    Dijkstra(0);
    printf("\n\nBellman- Ford Algorithm:\n\n");
    Bellman_Ford(0);
    printf("\n\n");

    return 0;
}