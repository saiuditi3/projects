#include <stdio.h>
#include <math.h>

//Number of nodes in the graph
#define n 6

/*
Structure of the Graph Given
dist[i][j] is the distance from j to i
*/
float dist[n][n]=
{
    {0,INFINITY,INFINITY,INFINITY,INFINITY,INFINITY},
    {3,0,3,6,15,2},
    {INFINITY,3,0,INFINITY,INFINITY,9},
    {1,6,INFINITY,0,12,INFINITY},
    {INFINITY,15,INFINITY,12,0,6},
    {INFINITY,2,9,INFINITY,6,0}
};

//Order in which Nodes are visited
int visited_order[n];

//Shortest Distance from Source to ith node
float dist_result[n];

//i_th row is the path to i_th node
float paths[n][n];

//Check if a node has already been visited
float alreadyvisited(int visited_order[],int k)
{
    for(int i=0;i<n;i++)
    {
        if(visited_order[i]==k){return 1;}
    }
    return 0;
}

//Display statistics
void display_distance(int i)
{    
    
    printf("%d |",i);
    for(int j=0;j<n;j++)
    {
        printf("%d ",(int)visited_order[j]);
    }printf("| ");

    for(int j=0;j<n;j++)
    {
        printf("%d ",(int)dist_result[j]);
    }printf("|\n");

}

void initialize()
{
    for(int i=0;i<n;i++)
    {
        //Setting all values of visited order to 0
        visited_order[i]=-1;

        //Setting all Distances to INFINITY
        dist_result[i]=INFINITY;
        
        //Setting all values of the paths taken to -1
        for(int j=0;j<n;j++)
        {
            paths[i][j]=-1;
        }
    }
}

//Implements Dijkstra's Algorithm
void Dijkstra(int src)
{
    initialize();
    int present=src;//Node from which distances are calculated at present iteration; initially set to source
    dist_result[present]=0;//Set distance to source as 0

    //To display statistics for each iteration
    printf("i |Nodes Gone to| Distances    |\n");

    //Iterate through n nodes
    for(int i=0;i<n;i++)
    {
        float min=INFINITY,//Minimum distance from a node
        min_node=INFINITY;//Node to which distance is minimum

        //Iterate through remaining nodes
        for(int k=0;k<n;k++)
        {
            //Go to all unvisited nodes only
            if(k!=present && !alreadyvisited(visited_order,k))
            {                
                //Finding the Nearest Node to present
                if(dist[k][present]<=min)
                {
                    min_node=k;
                    min=dist[k][present];
                }

                //Update distance and path
                if(dist_result[present]+dist[k][present]<dist_result[k])
                {
                    
                    if(dist_result[k]==INFINITY)
                    {
                        dist_result[k]=0;
                    }

                    //Update the path for k_th node
                    for(int j=0;j<n;j++)
                    {
                        if(paths[present][j]==-1)
                        {
                            paths[k][j]=present;//Add present node at the end of path
                            break;
                        }
                        paths[k][j]=paths[present][j];//Copy path to present

                    }
                    //Update the value of distance
                    dist_result[k]=dist_result[present]+dist[k][present];
                    
                }
            }
        }
        
        //Updating the order of Visits
        visited_order[i]=present;

        //Updating the present node to the node with least distance
        present=min_node;

        //Display Distances
        display_distance(i);
    }


    //Displaying Results
    
    //Display the order in which nodes are visited
    printf("The nodes visited were:\n");
    for(int j=0;j<n-1;j++)
    {
        printf("%c->",65+(int)visited_order[j]);
    }printf("%c\n\n",65+(int)visited_order[n-1]);
    
    //Display Distance to each node from source
    printf("\nDistances to nodes from Node %c are:\nNode  Distance\n",65+src);
    for(int j=0;j<n;j++)
    {
        printf(" %c\t %d\n",65+j,(int)dist_result[j]);
    }printf("\n\n");
    
    //Display the Paths taken to each node
    for(int i=0;i<n;i++)
    {
        int j=0;
        printf("Path to Node %c:\n",65+(int)i);
       for(int j=0;j<n;j++)
        {
            if(paths[i][j]!=-1)
            {
            printf("%c->",65+(int)paths[i][j]);
            }
        }printf("%c\n\n",65+i);

    }
}

//Main Function
int main()
{
    //Setting all values of the paths taken to -1
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            paths[i][j]=-1;
        }
    }
    
    //Calling the Dijkstra's Algorithm Function
    Dijkstra(0);
    
    return 0;
}