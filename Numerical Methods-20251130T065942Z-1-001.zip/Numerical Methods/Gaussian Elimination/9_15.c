#include <stdio.h>
#include <stdlib.h>
#include<math.h>

void Gauss(double** array,double* RHS_Gauss,double* Result,int n);
void AddElements(double** array,double **RHS, int n);
void Display(double** array, int n);
void GenerateMatrix(double** Matrix,double** NewMatrix,double** RHS,double* NewRHS,int n);

void GenerateMatrix(double** Matrix,double** NewMatrix,double** RHS,double* NewRHS,int n)
{
    for(int i=0;i<n/2;i++)
    {
        for(int j=0;j<n/2;j++)
        {
            //Equation for Real Part
        
            NewMatrix[2*i][2*j]=Matrix[i][2*j];//Coeff of Real Term
            NewMatrix[2*i][2*j+1]=-Matrix[i][2*j+1];//Negative of the Product coeff of imaginary terms
            //NewRHS[i]=RHS[i][0];//Real Part of RHS
        
            
            //Equation for Imaginary Part
        
            NewMatrix[2*i+1][2*j]=Matrix[i][2*j+1];
            NewMatrix[2*i+1][2*j+1]=Matrix[i][2*j];
            //NewRHS[i]=RHS[i][1];//Imaginary Part of RHS
            
        }
        NewRHS[2*i]=RHS[i][0];
        NewRHS[2*i+1]=RHS[i][1];
    }
}

//To add elements to array
void AddElements(double** array,double **RHS, int n)
{
    //Loop variables
    int i,j;
    
    //Runs from 0 to n-1
    for(i=0;i<n/2;i++)
    {
        printf("\nEquation %d\n",i+1);
        
        //Takes elements in a row
        for(j=0;j<n/2;j++)
        {
            printf("Enter Coefficient of x%d:\n",j+1);
            printf("Real:");
            scanf("%lf",&array[i][2*j]);
            printf("Imaginary:");
            scanf("%lf",&array[i][2*j+1]);
        }

        //Stores the Value on the RHS
        printf("Enter the RHS:\n");
        printf("Real:");
        scanf("%lf",&RHS[i][0]);
        printf("Imaginary:");
        scanf("%lf",&RHS[i][1]);
    }
}


//Display array
void Display(double** array, int n)
{
    printf("\n");

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            printf("%lf\t", array[i][j]);
        }
        printf("\n");
    }
}

//Does LU Decomposition of array
void LU_Decomposition(double** array,double* RHS_Gauss,double* Result,int n)
{
    int max=0,//Maximum Value of Coefficient
    max_row;//The row with the Largest Coefficient

    double factor;//Factor by which the equation is scaled; The element in the L Matrix
    double TempArr[n],//To Swap Elements of Arrays
    RHS[n];//To keep the RHS Unchanged for LD=B
    
    
    //Copying Elements from RHS_Gauss(which will be modified) to RHS
    for(int i=0;i<n;i++)
    {
        RHS[i]=RHS_Gauss[i];
    }


    //For every Coefficient Elimination
    for(int i=0;i<n;i++)
    {
        //Finds the row with the highest coeff
       /*  for(int j=i;j<n;j++)
        {
            if(fabs(array[j][i])>max)
            {
                max=fabs(array[j][i]);
                max_row=j;
            }
        }

        //Swaps ith row with jth row
        for(int temp=0;temp<n;temp++)
        {
            //Swap Elements of the Coefficient Matrix
            TempArr[temp]=array[i][temp];
            array[i][temp]=array[max_row][temp];
            array[max_row][temp]=TempArr[temp];
        }

        //Swap Elements of the RHS_Gauss Matrix
        TempArr[0]=RHS_Gauss[max_row];
        RHS_Gauss[max_row]=RHS_Gauss[i];
        RHS_Gauss[i]=TempArr[0]; 

        //Swap Elements of RHS Matrix
        TempArr[0]=RHS[max_row];
        RHS[max_row]=RHS[i];
        RHS[i]=TempArr[0]; */

        /*Gauss Elimination to Find U and L
        U and L are Stored in the array matrix after modifying it*/
       for(int j=i+1;j<n;j++)
       {
            factor=array[j][i]/array[i][i];      
            
            //Scaling ith Equation and Subtracting it from the jth
            for(int k=0;k<n;k++)
            {
                array[j][k]=(double)(array[j][k]-factor*array[i][k]);
            }
            RHS_Gauss[j]=RHS_Gauss[j]-factor*RHS_Gauss[i];
            //Storing the Element in the L Matrix
            array[j][i]=factor;
       }
    }
    
    //Forward Substitution using L and B to find D
    for(int i=0;i<n;i++)
    {
        Result[i]=RHS[i];
        for(int j=0;j<i;j++)
        {
            Result[i]=Result[i]-array[i][j]*Result[j];
        }
    }

    //Copying D to the RHS, to solve for X;Resetting Result matrix to all zeroes
    for(int i=0;i<n;i++)
    {
        RHS[i]=Result[i];
        Result[i]=0;
    }


    
    //Backward Substitution using U and D to find X
    for(int i=n-1;i>-1;i--)
    {
        Result[i]=RHS_Gauss[i];
        for(int j=n-1;j>i;j--)
        {
            Result[i]=Result[i]-array[i][j]*Result[j];
        }
        Result[i]/=array[i][i];
    }
     
}


int main()
{
    int n,//Number of Variables
    i,j;//Loop variables

    double **Matrix,//Coefficient Matrix taken as input
    **NewMatrix,//The system of equations generated to solve the problem
    **RHS,//RHS Matrix
    *NewRHS,//RHS Matrix generated
    *Result;//Solution Matrix

    //Obtains the number of rows
    printf("Enter the Number of Rows:");
    scanf("%d",&n);

    n*=2;//To store the real and imaginary parts

    
    //Allocate the Arrays
    RHS=malloc(2*sizeof *RHS);//2 Columns
    NewRHS=malloc(n*sizeof(double));
    Result=malloc(n*sizeof(double));
    Matrix = malloc(n * sizeof *Matrix);
    NewMatrix = malloc(n * sizeof *NewMatrix);
    
    //(n/2) Rows
    for(i=0;i<2;i++)
    {
        RHS[i] = malloc((n/2) * sizeof *RHS[i]);
    }


    for (i=0; i<n; i++)
    {
        Matrix[i] = malloc((n/2) * sizeof *Matrix[i]);
        NewMatrix[i] = malloc(n * sizeof *NewMatrix[i]);
    }

    //Add Elements to the Array
    AddElements(Matrix,RHS,n);

    //To Generate Solutions
    GenerateMatrix(Matrix,NewMatrix,RHS,NewRHS,n);

    //LU Decompose the array 
    LU_Decomposition(NewMatrix,NewRHS,Result,n);

    
    //Display the Roots
    printf("\nThe solutions are:\n");
    
    for(i=0;i<n/2;i++)
    {
        printf("x%d=%lf+%lfi\n",i+1,Result[2*i],Result[2*i+1]);
    }
   
    
    /* deallocate the array */
    for (i=0; i<n; i++)
    {        

        free(Matrix[i]);
    }

    free(Matrix);free(RHS);free(Result);
    
}