#include <stdio.h>
#include <stdlib.h>
#include<math.h>

/*
AX=B is the equation to Solve =>Done
Coefficient Array is initially A =>Done
L and U are stored in Coeff Arr(It is modified) =>Done
Forward substitution of LD=B to find D =>Done
Backward Substitution of UX=D to find X =>Done
*/
  
void AddElements(double** array,double *RHS, int n);
void Display(double** array,double *RHS, int n);

//To add elements to array
void AddElements(double** array,double *RHS, int n)
{
    //Loop variables
    int i,j;
    
    //Runs from 0 to n-1
    for(i=0;i<n;i++)
    {
        printf("\nEquation %d\n",i+1);
        
        //Takes elements in a row
        for(j=0;j<n;j++)
        {
            printf("Enter Coefficient of x%d:",j+1);
            scanf("%lf",&array[i][j]);
        }

        //Stores the Value on the RHS
        printf("Enter the RHS:");
        scanf("%lf",&RHS[i]);
    }

}

/*Function to Decompose array to L and U, which are stored in array itself
Also does forward and backward substitution to find the Solution
*/
void LU_Decomposition(double** array,double* RHS_Gauss,double* Result,int n)
{
    int max=0,//Maximum Value of Coefficient
    max_row;//The row with the Largest Coefficient

    double factor;//Factor by which the equation is scaled; The element in the L Matrix
    double TempArr[n],//To Swap Elements of Arrays
    RHS[n];//To keep the RHS Unchanged for LD=B
    
    
    //Copying Elements from RHS_Gauss(which will be modified) to RHS
    for(int i=0;i<n;i++)
    {
        RHS[i]=RHS_Gauss[i];
    }


    //For every Coefficient Elimination
    for(int i=0;i<n;i++)
    {
        //Finds the row with the highest coeff
        for(int j=i;j<n;j++)
        {
            if(fabs(array[j][i])>max)
            {
                max=fabs(array[j][i]);
                max_row=j;
            }
        }

        //Swaps ith row with jth row
        for(int temp=0;temp<n;temp++)
        {
            //Swap Elements of the Coefficient Matrix
            TempArr[temp]=array[i][temp];
            array[i][temp]=array[max_row][temp];
            array[max_row][temp]=TempArr[temp];
        }

        //Swap Elements of the RHS_Gauss Matrix
        TempArr[0]=RHS_Gauss[max_row];
        RHS_Gauss[max_row]=RHS_Gauss[i];
        RHS_Gauss[i]=TempArr[0]; 

        //Swap Elements of RHS Matrix
        TempArr[0]=RHS[max_row];
        RHS[max_row]=RHS[i];
        RHS[i]=TempArr[0]; 

        /*Gauss Elimination to Find U and L
        U and L are Stored in the array matrix after modifying it*/
       for(int j=i+1;j<n;j++)
       {
            factor=array[j][i]/array[i][i];      
            
            //Scaling ith Equation and Subtracting it from the jth
            for(int k=0;k<n;k++)
            {
                array[j][k]=(double)(array[j][k]-factor*array[i][k]);
            }
            RHS_Gauss[j]=RHS_Gauss[j]-factor*RHS_Gauss[i];
            //Storing the Element in the L Matrix
            array[j][i]=factor;
       }
    }
    
    //Forward Substitution using L and B to find D (LD=B)
    for(int i=0;i<n;i++)
    {
        Result[i]=RHS[i];
        for(int j=0;j<i;j++)
        {
            Result[i]=Result[i]-array[i][j]*Result[j];
        }
    }

    //Copying D to the RHS, to solve for X;Resetting Result matrix to all zeroes
    for(int i=0;i<n;i++)
    {
        RHS[i]=Result[i];
        Result[i]=0;
    }


    
    //Backward Substitution using U and D to find X
    for(int i=n-1;i>-1;i--)
    {
        Result[i]=RHS_Gauss[i];
        for(int j=n-1;j>i;j--)
        {
            Result[i]=Result[i]-array[i][j]*Result[j];
        }
        Result[i]/=array[i][i];
    }
     
}

//Display array and RHS
void Display(double** array,double *RHS, int n)
{
    printf("\n");

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            printf("%lf\t", array[i][j]);
        }
        printf("\t\t%lf\n",RHS[i]);
    }
}


int main()
{
    int n,//Number of Variables
    i,j;//Loop variables

    double **Coeff,//Coefficient Matrix
    *RHS,//RHS Matrix
    *Result;//Solution Matrix

    /* obtain values for rows & cols */
    printf("Enter the Number of Rows:");
    scanf("%d",&n);

    //Initialize the Arrays
    RHS=malloc(n*sizeof(double));
    Result=malloc(n*sizeof(double));
    Coeff = malloc(n * sizeof *Coeff);
    
    for (i=0; i<n; i++)
    {
        Coeff[i] = malloc(n * sizeof *Coeff[i]);
    }

    //Add Elements to the Coeff Array
    AddElements(Coeff,RHS, n);

    //Calls Decomposition Function
    LU_Decomposition(Coeff,RHS,Result,n);

    //Displays the Arrays after Decomposition
    Display(Coeff,RHS,n);

    //Display the Roots
    for(i=0;i<n;i++)
    {
        printf("%lf\n",Result[i]);
    }
    
    //Deallocate All Arrays
    for (i=0; i<n; i++)
    {
        free(Coeff[i]);
    }

    free(Coeff);free(RHS);free(Result);
}