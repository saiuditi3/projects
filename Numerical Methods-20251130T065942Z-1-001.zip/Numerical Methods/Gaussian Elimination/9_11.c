#include <stdio.h>
#include <stdlib.h>
#include<math.h>

void Gauss(double** array,double* RHS_Gauss,double* Result,int n);
void AddElements(double** array,double *RHS, int n);
void Display(double** array, int n);

//To add elements to array
void AddElements(double** array,double *RHS, int n)
{
    //Loop variables
    int i,j;
    
    //Runs from 0 to n-1
    for(i=0;i<n;i++)
    {
        printf("\nEquation %d\n",i+1);
        
        //Takes elements in a row
        for(j=0;j<n;j++)
        {
            printf("Enter Coefficient of x%d:",j+1);
            scanf("%lf",&array[i][j]);
        }

        //Stores the Value on the RHS
        printf("Enter the RHS:");
        scanf("%lf",&RHS[i]);
    }

}


//Display array
void Display(double** array, int n)
{
    printf("\nL and U Matrices in the Efficient Format:\n");

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            printf("%lf\t", array[i][j]);
        }
        printf("\n");
    }
}

//Does LU Decomposition of array
void Gauss(double** array,double* RHS_Gauss,double* Result,int n)
{
    int max=0,//Maximum Value of Coefficient
    max_row;//The row with the Largest Coefficient

    double factor;//Factor by which the equation is scaled; The element in the L Matrix
    double TempArr[n],//To Swap Elements of Arrays
    determinant=1;//To store the determinant of array


    //For every Coefficient Elimination
    for(int i=0;i<n;i++)
    {


        //Finds the row with the highest coeff
        for(int j=i;j<n;j++)
        {

            if(fabs(array[j][i])>max)
            {
                max=fabs(array[j][i]);
                max_row=j;
            }
        }

        //Swaps ith row with jth row
        for(int temp=0;temp<n;temp++)
        {
            //Swap Elements of the Coefficient Matrix
            TempArr[temp]=array[i][temp];
            array[i][temp]=array[max_row][temp];
            array[max_row][temp]=TempArr[temp];
        }

        //Swap Elements of the RHS_Gauss Matrix
        TempArr[0]=RHS_Gauss[max_row];
        RHS_Gauss[max_row]=RHS_Gauss[i];
        RHS_Gauss[i]=TempArr[0]; 

        //Gauss Elimination
       for(int j=i+1;j<n;j++)
       {
            factor=array[j][i]/array[i][i];      
            
            //Scaling ith Equation and Subtracting it from the jth
            for(int k=0;k<n;k++)
            {
                array[j][k]=(double)(array[j][k]-factor*array[i][k]);
            }
            
            //Doing the same for RHS
            RHS_Gauss[j]=RHS_Gauss[j]-factor*RHS_Gauss[i];
       }
    }
    
    //Backward Substitution to find X
    for(int i=n-1;i>-1;i--)
    {
        Result[i]=RHS_Gauss[i];
        for(int j=n-1;j>i;j--)
        {
            Result[i]=Result[i]-array[i][j]*Result[j];
        }
        Result[i]/=array[i][i];
    }

    //Finding the Determinant and displaying it
    for(int i=0;i<n;i++)
    {
        determinant*=array[i][i];
    }

    printf("\nThe determinant of the matrix is:%lf",determinant);
     
}


int main()
{
    int n,//Number of Variables
    i,j;//Loop variables

    double **Matrix,//Coefficient Matrix
    *RHS,//RHS Matrix
    *Result;//Solution Matrix

    //Obtains the number of rows
    printf("Enter the Number of Rows:");
    scanf("%d",&n);

    
    //Allocate the Arrays
    RHS=malloc(n*sizeof(double));
    Result=malloc(n*sizeof(double));
    Matrix = malloc(n * sizeof *Matrix);
    
    for (i=0; i<n; i++)
    {
        Matrix[i] = malloc(n * sizeof *Matrix[i]);
    }

    //Add Elements to the Array
    AddElements(Matrix,RHS,n);

    //LU Decompose the array 
    Gauss(Matrix,RHS,Result,n);

    //Display the Roots
    printf("\nThe solutions are:\n");
    for(i=0;i<n;i++)
    {
        printf("x%d=%lf\n",i+1,Result[i]);
    }
    
    /* deallocate the array */
    for (i=0; i<n; i++)
    {
        free(Matrix[i]);
    }

    free(Matrix);
}