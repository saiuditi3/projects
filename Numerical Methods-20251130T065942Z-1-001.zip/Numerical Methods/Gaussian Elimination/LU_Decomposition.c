#include <stdio.h>
#include <stdlib.h>
#include<math.h>

/*
AX=B is the equation to Solve =>Done
Coefficient Array is initially A =>Done
L and U are stored in Coeff Arr(It is modified) =>Done
Forward substitution of LD=B to find D =>Done
Backward Substitution of UX=D to find X 
*/

void AddElements(double** array, int n);
void Display(double** array, int n);


//To Add Elements to Array
void AddElements(double** array, int n)
{
    int i,j;//Loop Variables

    printf("Enter the elements of the Matrix:\n");
    
    //For each Row
    for(i=0;i<n;i++)
    {
        //Each element of a Row
        for(j=0;j<n;j++)
        {
            printf("a[%d][%d]:",i+1,j+1);
            scanf("%lf",&array[i][j]);
        }
    }
}

//Does LU Decomposition of array
void LU_Decomposition(double** array,int n)
{
    int max=0,//Maximum Value of Coefficient
    max_row;//The row with the Largest Coefficient

    double factor;//Factor by which the equation is scaled; The element in the L Matrix
    double TempArr[n],//To Swap Elements of Arrays
    RHS[n];//To keep the RHS Unchanged for LD=B

    //For every Coefficient Elimination
    for(int i=0;i<n;i++)
    {
        //Finds the row with the highest coeff
        for(int j=i;j<n;j++)
        {
            if(fabs(array[j][i])>max)
            {
                max=fabs(array[j][i]);
                max_row=j;
            }
        }

        //Swaps ith row with jth row
        for(int temp=0;temp<n;temp++)
        {
            //Swap Elements of the Coefficient Matrix
            TempArr[temp]=array[i][temp];
            array[i][temp]=array[max_row][temp];
            array[max_row][temp]=TempArr[temp];
        }

        /*Gauss Elimination to Find U and L
        U and L are Stored in the factor matrix after modifying it*/
       for(int j=i+1;j<n;j++)
       {
            factor=array[j][i]/array[i][i];      
            
            //Scaling ith Equation and Subtracting it from the jth
            for(int k=0;k<n;k++)
            {
                array[j][k]=(double)(array[j][k]-factor*array[i][k]);

            }
            
            //Storing the Element in the L Matrix
            array[j][i]=factor;

       }
    }
     
}


//Display array
void Display(double** array, int n)
{
    printf("\nL and U Matrices in the Efficient Format:\n");

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            printf("%lf\t", array[i][j]);
        }
        printf("\n");
    }
}


int main()
{
    int n,//Number of Variables
    i,j;//Loop variables

    double **Matrix;//Coefficient Matrix

    //Obtains the number of rows
    printf("Enter the Number of Rows:");
    scanf("%d",&n);

    
    //Allocate the Array
    Matrix = malloc(n * sizeof *Matrix);
    
    for (i=0; i<n; i++)
    {
        Matrix[i] = malloc(n * sizeof *Matrix[i]);
    }

    //Add Elements to the Array
    AddElements(Matrix,n);

    //LU Decompose the array 
    LU_Decomposition(Matrix,n);

    Display(Matrix,n);
    
    /* deallocate the array */
    for (i=0; i<n; i++)
    {
        free(Matrix[i]);
    }

    free(Matrix);
}