#include <stdio.h>
#include <stdlib.h>
#include<math.h>

/*
AX=B is the equation to Solve =>Done
Matrixicient Array is initially A =>Done
L and U are stored in Matrix Arr(It is modified) =>Done
Forward substitution of LD=B to find D =>Done
Backward Substitution of UX=D to find X 
*/
  
void AddElements(double** array,double *RHS, int n);
void Display(double** array, int n);

//To add elements to array
void AddElements(double** array,double *RHS, int n)
{
    //Loop variables
    int i,j;
    
    //Runs from 0 to n-1
    for(i=0;i<n;i++)
    {
        printf("\nEquation %d\n",i+1);
        
        //Takes elements in a row
        for(j=0;j<n;j++)
        {
            printf("Enter Coefficient of x%d:",j+1);
            scanf("%lf",&array[i][j]);
        }

        //Stores the Value on the RHS
        printf("Enter the RHS:");
        scanf("%lf",&RHS[i]);
    }

}

//LU Decompose the array Matrix
void LU_Decomposition(double** Matrix,double* RHS_Gauss,double* Result,int n)
{

    int max=0,//Maximum Value of Coefficient
    max_row;//The row with the Largest Coefficient

    double factor;//Factor by which the equation is scaled; The element in the L Matrix
    double TempArr[n],//To Swap Elements of Arrays
    RHS[n];//To keep the RHS Unchanged for LD=B
    float **array;//To copy the given Matrix

    //Initialising array
    array = malloc(n * sizeof *array);

    for (int i=0; i<n; i++)
    {
        array[i] = malloc(n * sizeof *array[i]);
    }
    
    //Copying Elements to array from Matrix
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            array[i][j]=Matrix[i][j];
        }
    }

    //Copying Elements from RHS_Gauss(which will be modified) to RHS
    for(int i=0;i<n;i++)
    {
        RHS[i]=RHS_Gauss[i];
    }


    //For every Coefficient Elimination
    for(int i=0;i<n;i++)
    {
        //Finds the row with the highest Matrix
        for(int j=i;j<n;j++)
        {
            if(fabs(array[j][i])>max)
            {
                max=fabs(array[j][i]);
                max_row=j;
            }
        }

        /*
        //Swaps ith row with jth row
        for(int temp=0;temp<n;temp++)
        {
            //Swap Elements of the Matrixicient Matrix
            TempArr[temp]=array[i][temp];
            array[i][temp]=array[max_row][temp];
            array[max_row][temp]=TempArr[temp];
        }

        //Swap Elements of the RHS_Gauss Matrix
        TempArr[0]=RHS_Gauss[max_row];
        RHS_Gauss[max_row]=RHS_Gauss[i];
        RHS_Gauss[i]=TempArr[0]; 

        //Swap Elements of RHS Matrix
        TempArr[0]=RHS[max_row];
        RHS[max_row]=RHS[i];
        RHS[i]=TempArr[0]; 
        */

        /*Gauss Elimination to Find U and L
        U and L are Stored in the factor matrix after modifying it*/
       for(int j=i+1;j<n;j++)
       {
            factor=array[j][i]/array[i][i];      
            
            //Scaling ith Equation and Subtracting it from the jth
            for(int k=0;k<n;k++)
            {
                array[j][k]=(double)(array[j][k]-factor*array[i][k]);
            }
            RHS_Gauss[j]=RHS_Gauss[j]-factor*RHS_Gauss[i];
            //Storing the Element in the L Matrix
            array[j][i]=factor;
       }
    }
    
    //Forward Substitution using L and B to find D
    for(int i=0;i<n;i++)
    {
        Result[i]=RHS[i];
        for(int j=0;j<i;j++)
        {
            Result[i]=Result[i]-array[i][j]*Result[j];
        }
    }

    //Copying D to the RHS, to solve for X;Resetting Result matrix to all zeroes
    for(int i=0;i<n;i++)
    {
        RHS[i]=Result[i];
        Result[i]=0;
    }

    //Backward Substitution using U and D to find X
    for(int i=n-1;i>-1;i--)
    {
        Result[i]=RHS_Gauss[i];
        for(int j=n-1;j>i;j--)
        {
            Result[i]=Result[i]-array[i][j]*Result[j];
        }
        Result[i]/=array[i][i];
    }

    //Deallocate array
    for (int i=0; i<n; i++)
    {
        free(array[i]);
    }
    free(array);
     
}

//Display elements of array
void Display(double** array, int n)
{
    printf("\n");

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            printf("%lf\t", array[i][j]);
        }
        printf("\n");
    }
}

//Function that finds the Inverse of Matrix and Stores it to Inverse; It uses LU_Decomposition()
void MatrixInverse(double** Matrix,double* RHS,double* Result,double **Inverse,int n)
{
    //For Each column of Inverse
    for(int col=0;col<n;col++)
    {
        //Setting the RHS
        for(int i=0;i<n;i++)
        {
            if(i==col)
            {
                RHS[i]=1;
            }
            else
            {
                RHS[i]=0;
            }
        }
        
        //Solves for the Column
        LU_Decomposition(Matrix,RHS,Result,n);
        
        //Stores the Value from Result to the Corresponding Column in Inverse
        for(int i=0;i<n;i++)
        {
            Inverse[i][col]=Result[i];
        }

        //Set all elements of Result to 0
        for(int i=0;i<n;i++)
        {
            Result[i]=0;
        }
    }
   
}


int main()
{
    int n,//Number of Rows of Matrix(Equal to number of Columns)
    i,j;//Loop variables
    double **Matrix,//Input Matrix
    *RHS,//RHS Matrix; used to store the rows of Identity Matrix
    *RHS_Initial,//RHS Matrix;Unmodified;
    *Result,//To store the solution of each system of linear equations;Reused to store the final solution
    **Inverse;//To store the inverse of Matrix
    

    double **NewMatrix,//For parts (c) and (d)
    *NewResult,//To store the Result for (c)
    *RHS_New;//New RHS for (c)

    //Obtain number of Rows(and columns since both are the same)
    printf("Enter the Number of Rows:");
    scanf("%d",&n);

    //Allocating the Arrays
    RHS=malloc(n*sizeof(double));
    RHS_Initial=malloc(n*sizeof(double));
    Result=malloc(n*sizeof(double));
    Matrix = malloc(n * sizeof *Matrix);
    Inverse=malloc(n*sizeof *Inverse);
    
    for (i=0; i<n; i++)
    {
        Matrix[i] = malloc(n * sizeof *Matrix[i]);
        Inverse[i]=malloc(n*sizeof *Inverse[i]);
    }
    
    //Add Elements to Matrix
    AddElements(Matrix,RHS, n);

    for(i=0;i<n;i++)
    {
        RHS_Initial[i]=RHS[i];
    }
    
    //Finds Inverse of Matrix
    MatrixInverse(Matrix,RHS,Result,Inverse,n);

    //Prints the given Matrix
    printf("\nThe Given Matrix is:\n");
    Display(Matrix,n);
    
    //Prints the Inverse
    printf("\nThe Inverse of the given Matrix is:\n");
    Display(Inverse,n);

    
    for(i=0;i<n;i++)
    {
        Result[i]=0;
        for(j=0;j<n;j++)
        {
            Result[i]+=Inverse[i][j]*RHS_Initial[j];
        }
    }

    printf("\nThe Roots Are:\n\n");

    for(i=0;i<n;i++)
    {
        printf("x%d=%lf\n",i+1,Result[i]);
    }

    
    
    //Allocating NewMatrix for c
    NewMatrix=malloc((n-1)*sizeof *NewMatrix);
    NewResult=malloc((n-1)*sizeof(double));
    RHS_New=malloc((n-1) * sizeof(double));
    RHS_Initial=realloc(RHS_Initial,(n-1) * sizeof(double));

    Inverse=realloc(Inverse,(n-1)*sizeof *Inverse);

    /*
    for(i=0;i<n-1;i++)
    {
        NewMatrix[i] = malloc((n-1) * sizeof *NewMatrix[i]);
        Inverse[i] = malloc((n-1) * sizeof *Inverse[i]);

    }
    

    for(i=0;i<n-1;i++)
    {
        RHS_New[i]=RHS[i]-Matrix[i][0]*(Result[i]+10);
        
        for(j=0;j<n-1;j++)
        {
            NewMatrix[i][j]=Matrix[i][j+1];
        }

    }

    MatrixInverse(Matrix,RHS,Result,Inverse,n);

    //Finds Inverse of Matrix
    MatrixInverse(NewMatrix,RHS_New,NewResult,Inverse,n-1);

    for(i=0;i<n-1;i++)
    {
        Result[i]=0;
        for(j=0;j<n-1;j++)
        {
            NewResult[i]+=Inverse[i][j]*RHS_Initial[j];
        }
    }
    */

    

    //Deallocate all Arrays
    for (i=0; i<n; i++)
    {
        free(Matrix[i]);
        
        if(i!=n-1)
        {
        free(NewMatrix[i]);
        free(Inverse[i]);
        }
    }

    free(Matrix);free(Inverse);free(NewMatrix);free(RHS);free(RHS_Initial);free(Result);free(RHS_New);

}